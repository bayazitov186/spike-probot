import asyncio
import html
import os
import re
import tempfile
import time
from datetime import datetime

import aiosqlite
from aiogram import Bot, Router, F, types
from aiogram.exceptions import TelegramForbiddenError, TelegramRetryAfter
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import FSInputFile, LinkPreviewOptions
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import (
    state as app_state, ADMIN_IDS, DB_PATH, SOLANA_WSS, CHANNEL_ID,
    NPD_ANNUAL_LIMIT_RUB, NPD_WARNING_THRESHOLD_RUB
)
from database import (
    set_bot_setting, add_subscription_time, claim_fiat_and_add_sub,
    get_all_users, format_time_left, format_time_left_short, export_csv_files
)
from keyboards import get_admin_menu
from texts import get_channel_pinned_post
from workers.maintenance import send_evening_digest_if_due

router = Router()


class AdminStates(StatesGroup):
    waiting_for_broadcast = State()
    waiting_give_sub = State()
    waiting_check_user = State()


async def is_admin(event: types.CallbackQuery | types.Message) -> bool:
    uid = event.from_user.id
    if uid not in ADMIN_IDS:
        if isinstance(event, types.CallbackQuery):
            await event.answer("⛔️ Доступ запрещен.", show_alert=True)
        else:
            await event.answer("⛔️ Команда доступна только администраторам.")
        return False
    return True


async def get_extended_admin_stats() -> dict:
    current_time = time.time()
    current_year_prefix = f"{datetime.now().year}-"
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        async with db.execute("SELECT COUNT(*) FROM users") as cur:
            total_users = (await cur.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM users WHERE sub_end_timestamp > ?", (current_time,)) as cur:
            active_subs = (await cur.fetchone())[0]
        async with db.execute("SELECT COUNT(*), COALESCE(SUM(amount_rub), 0) FROM paid_fiat") as cur:
            row_fiat = await cur.fetchone()
            fiat_payments = row_fiat[0] or 0
            fiat_total_rub = row_fiat[1] or 0
        async with db.execute(
            "SELECT COALESCE(SUM(amount_rub), 0) FROM paid_fiat WHERE paid_at LIKE ?",
            (f"{current_year_prefix}%",)
        ) as cur_yr:
            year_rub = (await cur_yr.fetchone())[0] or 0
        async with db.execute("SELECT COUNT(DISTINCT referrer_id) FROM users WHERE referrer_id IS NOT NULL") as cur:
            active_referrers = (await cur.fetchone())[0]

    return {
        "total": total_users,
        "active": active_subs,
        "fiat_payments": fiat_payments,
        "fiat_total_rub": int(fiat_total_rub),
        "year_rub": int(year_rub),
        "active_referrers": active_referrers
    }


async def get_accuracy_report_text() -> str:
    one_day_ago = time.time() - 86400
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN result = 'WIN' THEN 1 ELSE 0 END) as wins,
                SUM(CASE WHEN result = 'LOSS' THEN 1 ELSE 0 END) as losses,
                SUM(CASE WHEN result = 'BE' THEN 1 ELSE 0 END) as be,
                AVG(CASE WHEN result = 'WIN' THEN max_profit_1h ELSE NULL END) as avg_profit,
                AVG(CASE WHEN result = 'WIN' THEN vol_ratio ELSE NULL END) as win_avg_vol,
                AVG(CASE WHEN result = 'WIN' THEN oi_change ELSE NULL END) as win_avg_oi,
                AVG(CASE WHEN result = 'LOSS' THEN vol_ratio ELSE NULL END) as loss_avg_vol,
                AVG(CASE WHEN result = 'LOSS' THEN oi_change ELSE NULL END) as loss_avg_oi
            FROM signals_history 
            WHERE created_at >= ? AND result IN ('WIN', 'LOSS', 'BE')
        """, (one_day_ago,)) as cur:
            row = dict(await cur.fetchone())

        async with db.execute(
            "SELECT COUNT(*) FROM signals_history WHERE created_at >= ? AND result = 'PENDING'",
            (one_day_ago,)
        ) as cur_pend:
            pending_count = (await cur_pend.fetchone())[0] or 0

        async with db.execute("""
            SELECT symbol, side, max_profit_1h 
            FROM signals_history 
            WHERE created_at >= ? AND result = 'WIN'
            ORDER BY max_profit_1h DESC LIMIT 3
        """, (one_day_ago,)) as cur_top:
            top_signals = [dict(r) for r in await cur_top.fetchall()]

    total = row['total'] or 0
    wins = row['wins'] or 0
    losses = row['losses'] or 0
    avg_p = row['avg_profit'] or 0.0
    winrate = (wins / total * 100) if total > 0 else 0.0

    win_vol = row['win_avg_vol'] or 0.0
    win_oi = row['win_avg_oi'] or 0.0
    loss_vol = row['loss_avg_vol'] or 0.0
    loss_oi = row['loss_avg_oi'] or 0.0

    if total == 0:
        return (
            "🎯 <b>Аудит сигналов Spike PRO (за последние 24ч)</b>\n\n"
            f"⏳ В работе (PENDING): <b>{pending_count}</b>\n\n"
            "ℹ️ <i>Закрытых записей пока нет. Статистика накапливается "
            "по мере отработки свечей (через 60 мин после импульсов).</i>"
        )

    text = (
        f"🎯 <b>Аудит сигналов Spike PRO (за последние 24ч)</b>\n\n"
        f"📊 Отработано записей: <b>{total}</b> (в работе: <b>{pending_count}</b>)\n"
        f"✅ Положительных (WIN): <b>{wins}</b>\n"
        f"❌ Отрицательных (LOSS): <b>{losses}</b>\n"
        f"⚪️ Нейтральных (BE): <b>{row['be'] or 0}</b>\n\n"
        f"🔥 <b>Точность алгоритма:</b> <code>{winrate:.1f}%</code>\n"
        f"📈 Средний импульс (WIN): <code>+{avg_p:.2f}%</code>\n\n"
        f"🔬 <b>Диагностика параметров (средние):</b>\n"
        f"• WIN: Vol <code>x{win_vol:.1f}</code> | OI <code>{win_oi:+.2f}%</code>\n"
        f"• LOSS: Vol <code>x{loss_vol:.1f}</code> | OI <code>{loss_oi:+.2f}%</code>\n"
    )
    if top_signals:
        text += "\n🏆 <b>Топ движений за сегодня:</b>\n"
        for t in top_signals:
            text += f"• <b>#{t['symbol']}</b> ({t['side']}): <code>+{t['max_profit_1h']}%</code>\n"
    return text


@router.message(Command("admin"))
async def cmd_admin(message: types.Message, state: FSMContext):
    if not await is_admin(message):
        return
    await state.clear()
    await message.answer("👑 <b>Панель управления Spike PRO</b>\nВыберите раздел для работы:", reply_markup=get_admin_menu())


@router.message(Command("pin_rules"))
async def cmd_pin_rules(message: types.Message, bot: Bot):
    if not await is_admin(message):
        return
    if not CHANNEL_ID:
        return await message.answer("❌ CHANNEL_ID не задан в .env")
    try:
        sent = await bot.send_message(
            chat_id=CHANNEL_ID,
            text=get_channel_pinned_post(app_state.cached_bot_username),
            link_preview_options=LinkPreviewOptions(is_disabled=True)
        )
        await bot.pin_chat_message(chat_id=CHANNEL_ID, message_id=sent.message_id, disable_notification=True)
        await message.answer("✅ Пост с дисклеймером и офертой опубликован и закреплён в канале.")
    except Exception as e:
        await message.answer(f"❌ Ошибка публикации/закрепления: <code>{html.escape(str(e))}</code>")


@router.message(Command("digest"))
async def cmd_digest(message: types.Message, bot: Bot):
    if not await is_admin(message):
        return
    ok = await send_evening_digest_if_due(bot, force=True)
    if ok:
        await message.answer("✅ Вечерний дайджест опубликован в канал.")
    else:
        await message.answer("⚠️ За последние 24 часа пока нет данных для формирования дайджеста.")


@router.message(Command("accuracy"))
async def cmd_accuracy(message: types.Message):
    if not await is_admin(message):
        return
    await message.answer(await get_accuracy_report_text())


@router.callback_query(F.data == "admin_toggle_solana")
async def cb_admin_toggle_solana(callback: types.CallbackQuery):
    if not await is_admin(callback):
        return
    if not SOLANA_WSS and not app_state.solana_enabled:
        return await callback.answer("❌ SOLANA_WSS не задан в .env", show_alert=True)

    app_state.solana_enabled = not app_state.solana_enabled
    await set_bot_setting("solana_sniper_enabled", "1" if app_state.solana_enabled else "0")
    status = "включен 🟢" if app_state.solana_enabled else "отключен 🔴 (лимиты Helius не расходуются)"
    await callback.answer(f"Мониторинг Solana {status}", show_alert=True)
    await callback.message.edit_reply_markup(reply_markup=get_admin_menu())


@router.callback_query(F.data == "admin_toggle_pause")
async def cb_admin_toggle_pause(callback: types.CallbackQuery):
    if not await is_admin(callback):
        return
    app_state.emergency_pause = not app_state.emergency_pause
    await set_bot_setting("emergency_pause", "1" if app_state.emergency_pause else "0")
    status = "поставлен на паузу ⏸" if app_state.emergency_pause else "возобновлен 🟢"
    await callback.answer(f"Скринер {status}", show_alert=True)
    await callback.message.edit_reply_markup(reply_markup=get_admin_menu())


@router.callback_query(F.data.startswith("admin_tbl_"))
async def cb_admin_table_view(callback: types.CallbackQuery):
    if not await is_admin(callback):
        return
    parts = callback.data.split("_")
    mode = parts[2] if len(parts) > 2 else "users"
    page = int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 0
    per_page = 15

    await callback.answer()

    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        if mode == "signals":
            async with db.execute("SELECT COUNT(*) FROM signals_history") as cur:
                total_rows = (await cur.fetchone())[0]
            total_pages = max(1, (total_rows + per_page - 1) // per_page)
            page = max(0, min(page, total_pages - 1))
            offset = page * per_page

            async with db.execute(
                "SELECT symbol, side, result, max_profit_1h FROM signals_history ORDER BY id DESC LIMIT ? OFFSET ?",
                (per_page, offset)
            ) as cur:
                rows = [dict(r) for r in await cur.fetchall()]

            lines = ["Пара       | Side | Итог | Max%"]
            lines.append("-----------+------+------+-------")
            for r in rows:
                sym = r['symbol'].replace("USDT", "")[:10].ljust(10)
                sd = ("LONG" if r['side'] == "LONG" else "SHRT").ljust(4)
                raw_res = r['result'] or "PEND"
                res = raw_res[:4].ljust(4)
                val_pnl = r['max_profit_1h'] or 0.0
                pnl = "..." if raw_res == "PENDING" else f"{val_pnl:+.1f}%"
                lines.append(f"{sym} | {sd} | {res} | {pnl}")

            table_body = "\n".join(lines) if rows else "Записей пока нет."
            header = f"📈 <b>Таблица мониторинга</b> (Всего: {total_rows} | Стр. {page + 1}/{total_pages})"
        else:
            mode = "users"
            async with db.execute("SELECT COUNT(*) FROM users") as cur:
                total_rows = (await cur.fetchone())[0]
            total_pages = max(1, (total_rows + per_page - 1) // per_page)
            page = max(0, min(page, total_pages - 1))
            offset = page * per_page

            async with db.execute(
                "SELECT user_id, sub_end_timestamp, min_volume_mult, min_price_change, min_oi_change, alerts_enabled FROM users ORDER BY sub_end_timestamp DESC LIMIT ? OFFSET ?",
                (per_page, offset)
            ) as cur:
                rows = [dict(r) for r in await cur.fetchall()]

            lines = ["ID         | Доступ   | V/P/OI"]
            lines.append("-----------+----------+-----------")
            for r in rows:
                uid_str = str(r['user_id']).ljust(10)
                rem = format_time_left_short(r['sub_end_timestamp'])
                if not r.get('alerts_enabled', 1):
                    rem = "ПАУЗА"
                rem_str = rem[:8].ljust(8)
                flt = f"{r['min_volume_mult']:.1f}/{r['min_price_change']:.1f}/{r['min_oi_change']:.1f}"
                lines.append(f"{uid_str} | {rem_str} | {flt}")

            table_body = "\n".join(lines) if rows else "Пользователей пока нет."
            header = f"👥 <b>База пользователей</b> (Всего: {total_rows} | Стр. {page + 1}/{total_pages})"

    builder = InlineKeyboardBuilder()
    if total_pages > 1:
        nav_btns = []
        if page > 0:
            nav_btns.append(types.InlineKeyboardButton(text="⬅️ Пред.", callback_data=f"admin_tbl_{mode}_{page - 1}"))
        nav_btns.append(types.InlineKeyboardButton(text=f"{page + 1}/{total_pages}", callback_data=f"admin_tbl_{mode}_{page}"))
        if page < total_pages - 1:
            nav_btns.append(types.InlineKeyboardButton(text="След. ➡️", callback_data=f"admin_tbl_{mode}_{page + 1}"))
        builder.row(*nav_btns)

    if mode == "users":
        builder.row(types.InlineKeyboardButton(text="📈 Переключить на таблицу мониторинга", callback_data="admin_tbl_signals_0"))
    else:
        builder.row(types.InlineKeyboardButton(text="👥 Переключить на таблицу пользователей", callback_data="admin_tbl_users_0"))

    builder.row(
        types.InlineKeyboardButton(text="📊 Скачать CSV (Excel)", callback_data="admin_export_csv"),
        types.InlineKeyboardButton(text="📦 Скачать .DB", callback_data="admin_dump_db")
    )
    builder.row(types.InlineKeyboardButton(text="◀️ Назад в админку", callback_data="admin_back_main"))

    text = f"{header}\n\n<pre>{html.escape(table_body)}</pre>"
    try:
        await callback.message.edit_text(text, reply_markup=builder.as_markup())
    except Exception:
        await callback.message.answer(text, reply_markup=builder.as_markup())


@router.callback_query(F.data == "admin_export_csv")
async def cb_admin_export_csv(callback: types.CallbackQuery):
    if not await is_admin(callback):
        return
    await callback.answer("Формирую CSV-таблицы...")
    users_csv, signals_csv = "", ""
    try:
        users_csv, signals_csv, u_cnt, s_cnt = await export_csv_files()
        await callback.message.answer_document(
            document=FSInputFile(users_csv),
            caption=f"👥 <b>Таблица пользователей (вкл. акцепт оферты)</b> ({u_cnt} записей)"
        )
        await callback.message.answer_document(
            document=FSInputFile(signals_csv),
            caption=f"📈 <b>Таблица мониторинга</b> ({s_cnt} записей)"
        )
    except Exception as e:
        await callback.message.answer(f"❌ Ошибка выгрузки CSV: <code>{html.escape(str(e))}</code>")
    finally:
        for path in (users_csv, signals_csv):
            if path and os.path.exists(path):
                os.remove(path)


@router.callback_query(F.data == "admin_dump_db")
async def cb_admin_dump_db(callback: types.CallbackQuery):
    if not await is_admin(callback):
        return
    await callback.answer("Подготовка слепка базы...")
    snapshot_path = os.path.join(tempfile.gettempdir(), "manual_snapshot.db")
    try:
        async with aiosqlite.connect(DB_PATH, timeout=30) as src, aiosqlite.connect(snapshot_path) as dst:
            await src.backup(dst)
        date_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        await callback.message.answer_document(
            document=FSInputFile(snapshot_path),
            caption=f"📦 <b>Актуальный слепок БД</b>\nПуть: <code>{html.escape(DB_PATH)}</code>\nВремя: <code>{date_now}</code>"
        )
    finally:
        if os.path.exists(snapshot_path):
            os.remove(snapshot_path)


@router.callback_query(F.data == "admin_stats")
async def cb_admin_stats(callback: types.CallbackQuery):
    if not await is_admin(callback):
        return
    await callback.answer()
    s = await get_extended_admin_stats()
    year_rub = s['year_rub']
    rem_limit = max(0, NPD_ANNUAL_LIMIT_RUB - year_rub)
    pct_used = (year_rub / NPD_ANNUAL_LIMIT_RUB) * 100

    limit_warn = ""
    if year_rub >= NPD_WARNING_THRESHOLD_RUB:
        limit_warn = "\n⚠️ <b>ВНИМАНИЕ:</b> <i>Оборот приближается к годовому лимиту НПД (2.4 млн ₽)!</i>\n"

    text = (
        f"📊 <b>Детальная статистика терминала:</b>\n\n"
        f"👥 Всего пользователей: <b>{s['total']}</b>\n"
        f"💎 Активных PRO-доступов: <b>{s['active']}</b>\n"
        f"🔗 Активных партнеров: <b>{s['active_referrers']}</b>\n\n"
        f"🧾 <b>Налоговый контроль НПД ({datetime.now().year} год):</b>\n"
        f"• Оплат за всё время: <b>{s['fiat_payments']}</b> (<b>{s['fiat_total_rub']:,} ₽</b>)\n"
        f"• Доход за {datetime.now().year} г.: <b>{year_rub:,} ₽</b> ({pct_used:.1f}%)\n"
        f"• Остаток лимита (из 2.4 млн ₽): <b>{rem_limit:,} ₽</b>{limit_warn}\n\n"
        f"💾 Путь к БД: <code>{html.escape(DB_PATH)}</code>\n"
        f"🎯 Мониторинг Solana: <b>{'ВКЛЮЧЕН 🟢' if app_state.solana_enabled else 'ВЫКЛЮЧЕН 🔴'}</b>\n"
        f"⚙️ Общий скринер: <b>{'ПАУЗА ⏸' if app_state.emergency_pause else 'РАБОТАЕТ 🟢'}</b>"
    ).replace(",", " ")
    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text="🔄 Обновить", callback_data="admin_stats"))
    builder.row(types.InlineKeyboardButton(text="◀️ Назад", callback_data="admin_back_main"))
    await callback.message.edit_text(text, reply_markup=builder.as_markup())


@router.callback_query(F.data == "admin_accuracy")
async def cb_admin_accuracy(callback: types.CallbackQuery):
    if not await is_admin(callback):
        return
    await callback.answer("Сбор статистики...", show_alert=False)
    text = await get_accuracy_report_text()
    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text="🔄 Обновить", callback_data="admin_accuracy"))
    builder.row(types.InlineKeyboardButton(text="◀️ Назад в админку", callback_data="admin_back_main"))
    await callback.message.edit_text(text, reply_markup=builder.as_markup())


@router.callback_query(F.data == "admin_back_main")
async def cb_admin_back_main(callback: types.CallbackQuery, state: FSMContext):
    if not await is_admin(callback):
        return
    await callback.answer()
    await state.clear()
    await callback.message.edit_text("👑 <b>Панель управления Spike PRO</b>\nВыберите раздел для работы:", reply_markup=get_admin_menu())


@router.callback_query(F.data == "admin_clear_signals")
async def cb_admin_clear_signals(callback: types.CallbackQuery):
    if not await is_admin(callback):
        return
    await callback.answer("Очистка базы...")
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute("DELETE FROM signals_history;")
        await db.commit()
    try:
        async with aiosqlite.connect(DB_PATH, timeout=30, isolation_level=None) as db:
            await db.execute("VACUUM;")
    except Exception:
        pass
    await callback.message.edit_text(
        "🗑 <b>История мониторинга успешно очищена!</b>\n"
        "Запущен чистый сбор статистики по 1-минутным свечам.",
        reply_markup=get_admin_menu()
    )


@router.callback_query(F.data == "admin_give_sub")
async def cb_admin_give_sub(callback: types.CallbackQuery, state: FSMContext):
    if not await is_admin(callback):
        return
    await callback.answer()
    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text="◀️ Отмена", callback_data="admin_back_main"))
    await callback.message.edit_text(
        "🎁 <b>Выдача PRO-доступа</b>\n\n"
        "Отправьте сообщение в одном из форматов:\n"
        "1️⃣ <code>USER_ID ДНИ</code> — бесплатная выдача\n"
        "2️⃣ <code>USER_ID ДНИ СУММА_РУБ</code> — выдача с записью суммы в счётчик лимита НПД\n\n"
        "Примеры:\n"
        "<code>123456789 30</code>\n"
        "<code>123456789 30 1490</code>",
        reply_markup=builder.as_markup()
    )
    await state.set_state(AdminStates.waiting_give_sub)


@router.message(AdminStates.waiting_give_sub)
async def process_admin_give_sub(message: types.Message, state: FSMContext, bot: Bot):
    if not await is_admin(message):
        return
    parts = (message.text or "").strip().split()
    if len(parts) not in (2, 3) or not parts[0].isdigit() or not parts[1].lstrip('-').isdigit():
        await message.answer("❌ Неверный формат. Нужно: <code>USER_ID ДНИ</code> или <code>USER_ID ДНИ СУММА_РУБ</code>")
        return

    target_uid = int(parts[0])
    days = int(parts[1])
    amount_rub = 0.0
    if len(parts) == 3:
        try:
            amount_rub = float(parts[2].replace(',', '.'))
        except ValueError:
            return await message.answer("❌ Сумма в рублях должна быть числом.")

    if amount_rub > 0:
        manual_order_id = f"manual_{target_uid}_{int(time.time())}"
        await claim_fiat_and_add_sub(manual_order_id, target_uid, days, amount_rub, provider="manual_npd")
    else:
        await add_subscription_time(target_uid, days)

    await state.clear()

    if days > 0:
        try:
            await bot.send_message(target_uid, f"🎁 <b>Вам активирован PRO-доступ к ПО на {days} дн.!</b>")
        except Exception:
            pass

    rub_note = f" (учтено в лимите НПД: <b>+{amount_rub:,.0f} ₽</b>)".replace(",", " ") if amount_rub > 0 else ""
    await message.answer(
        f"✅ Пользователю <code>{target_uid}</code> обновлен срок доступа на <b>{days}</b> дн.{rub_note}",
        reply_markup=get_admin_menu()
    )


@router.callback_query(F.data == "admin_find_user")
async def cb_admin_find_user(callback: types.CallbackQuery, state: FSMContext):
    if not await is_admin(callback):
        return
    await callback.answer()
    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text="◀️ Отмена", callback_data="admin_back_main"))
    await callback.message.edit_text("🔍 Введите <b>Telegram ID</b> пользователя для проверки:", reply_markup=builder.as_markup())
    await state.set_state(AdminStates.waiting_check_user)


@router.message(AdminStates.waiting_check_user)
async def process_admin_check_user(message: types.Message, state: FSMContext):
    if not await is_admin(message):
        return
    raw_txt = (message.text or "").strip()
    if not raw_txt.isdigit():
        await message.answer("❌ Введите числовой Telegram ID:")
        return

    target_uid = int(raw_txt)
    await state.clear()

    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users WHERE user_id = ?", (target_uid,)) as cur:
            row = await cur.fetchone()

    if not row:
        await message.answer(f"❌ Пользователь <code>{target_uid}</code> не найден в базе.", reply_markup=get_admin_menu())
        return

    u = dict(row)
    sub_end = u['sub_end_timestamp']
    is_active = sub_end > time.time()
    sub_str = f"✅ До {datetime.fromtimestamp(sub_end).strftime('%d.%m.%Y %H:%M')} ({format_time_left(sub_end)})" if is_active else "❌ Истекла"
    acc_ts = u.get('offer_accepted_at') or 0
    acc_str = datetime.fromtimestamp(acc_ts).strftime('%d.%m.%Y %H:%M') if acc_ts > 0 else "Не зафиксирован"

    info = (
        f"👤 <b>Карточка пользователя:</b> <code>{target_uid}</code>\n\n"
        f"• Доступ к ПО: <b>{sub_str}</b>\n"
        f"• Уведомления включены: <b>{'Да 🔔' if u.get('alerts_enabled') else 'Нет 🔕'}</b>\n"
        f"• Акцепт оферты: <code>{acc_str}</code>\n"
        f"• Фильтры: Объем <code>{u['min_volume_mult']}x</code> | Цена <code>{u['min_price_change']}%</code> | ОИ <code>{u.get('min_oi_change', 0)}%</code>\n"
        f"• Блэклист: <code>{html.escape(u.get('blacklist') or 'Пусто')}</code>\n"
        f"• Приглашен пользователем: <code>{u.get('referrer_id') or 'Органический'}</code>"
    )
    await message.answer(info, reply_markup=get_admin_menu())


@router.callback_query(F.data == "admin_broadcast")
async def cb_admin_broadcast(callback: types.CallbackQuery, state: FSMContext):
    if not await is_admin(callback):
        return
    await callback.answer()
    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text="◀️ Отмена", callback_data="admin_back_main"))
    await callback.message.edit_text("📢 Отправьте сообщение для рассылки всем пользователям (поддерживает текст, фото, ссылки):", reply_markup=builder.as_markup())
    await state.set_state(AdminStates.waiting_for_broadcast)


@router.message(Command("cancel"), AdminStates.waiting_for_broadcast)
@router.message(Command("cancel"), AdminStates.waiting_give_sub)
@router.message(Command("cancel"), AdminStates.waiting_check_user)
async def cancel_admin_action(message: types.Message, state: FSMContext):
    await state.clear()
    await message.answer("❌ Действие отменено.", reply_markup=get_admin_menu())


@router.message(AdminStates.waiting_for_broadcast)
async def process_broadcast(message: types.Message, state: FSMContext, bot: Bot):
    if not await is_admin(message):
        return
    users = await get_all_users()
    sent, failed, blocked = 0, 0, 0
    msg = await message.answer(f"⏳ Рассылка запущена (получателей: {len(users)})...")

    for uid in users:
        try:
            await bot.copy_message(chat_id=uid, from_chat_id=message.chat.id, message_id=message.message_id)
            sent += 1
        except TelegramForbiddenError:
            blocked += 1
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after)
            try:
                await bot.copy_message(chat_id=uid, from_chat_id=message.chat.id, message_id=message.message_id)
                sent += 1
            except Exception:
                failed += 1
        except Exception:
            failed += 1
        finally:
            await asyncio.sleep(0.04)

    await msg.edit_text(
        f"✅ <b>Рассылка завершена!</b>\n\n"
        f"• Доставлено: <b>{sent}</b>\n"
        f"• Заблокировали бота: <b>{blocked}</b>\n"
        f"• Ошибок: <b>{failed}</b>",
        reply_markup=get_admin_menu()
    )
    await state.clear()


@router.message(F.reply_to_message)
async def admin_native_reply(message: types.Message, bot: Bot):
    if message.from_user.id not in ADMIN_IDS:
        return
    original_text = message.reply_to_message.text or message.reply_to_message.caption or ""
    if "Новое обращение" in original_text and "ID:" in original_text:
        match = re.search(r"ID:\s*(\d+)", original_text)
        if match:
            try:
                user_id = int(match.group(1))
                await bot.send_message(chat_id=user_id, text="👨‍💻 <b>Ответ от поддержки Spike PRO:</b>")
                await bot.copy_message(chat_id=user_id, from_chat_id=message.chat.id, message_id=message.message_id)
                await message.reply("✅ Ответ успешно доставлен пользователю.")
            except Exception as e:
                await message.reply(f"❌ Ошибка отправки:\n<code>{html.escape(str(e))}</code>")


@router.callback_query(F.data == "admin_close")
async def cb_admin_close(callback: types.CallbackQuery, state: FSMContext):
    if not await is_admin(callback):
        return
    await callback.answer()
    await state.clear()
    await callback.message.delete()