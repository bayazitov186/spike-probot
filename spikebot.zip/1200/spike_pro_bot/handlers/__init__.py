from aiogram import Dispatcher

from handlers.user import router as user_router
from handlers.payments import router as payments_router
from handlers.admin import router as admin_router


def register_routers(dp: Dispatcher):
    dp.include_router(payments_router)
    dp.include_router(admin_router)
    dp.include_router(user_router)