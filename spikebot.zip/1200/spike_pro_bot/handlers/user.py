import html
import os
import re
import tempfile
import time
from datetime import datetime

import aiohttp
from aiogram import Bot, Router, F, types
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import FSInputFile, LinkPreviewOptions, ReplyKeyboardRemove
from aiogram.utils.keyboard import InlineKeyboardBuilder
from curl_cffi.requests import AsyncSession

from config import (
    state as app_state, CHANNEL_ID, ADMIN_IDS, PROXY_URL, SOLANA_WSS,
    BYBIT_REF_CODE, BYBIT_REF_URL, REF_DISCOUNT_PERCENT
)
from database import (
    get_or_create_user, record_offer_acceptance, update_user_setting,
    get_referrals_count, get_active_subscribers, format_time_left
)
from keyboards import (
    get_sub_gate_keyboard, get_main_menu, get_profile_menu,
    get_presets_keyboard, get_setup_keyboard
)
from texts import (
    get_legal_text, get_full_legal_document_text,
    get_metrics_guide_document_text, FAQ_ITEMS
)

router = Router()

FILTER_PRESETS = {
    "preset_base": {"name": "⚖️ Базовый", "vol": 3.0, "price": 1.5, "oi": 1.2},
    "preset_fast": {"name": "⚡️ Частый", "vol": 2.2, "price": 1.0, "oi": 0.8},
    "preset_whale": {"name": "🐋 Крупный", "vol": 5.0, "price": 2.5, "oi": 2.0},
}


class UserSettingsFSM(StatesGroup):
    wait_vol = State()
    wait_price = State()
    wait_oi = State()


class BlacklistFSM(StatesGroup):
    wait_tickers = State()


class FeedbackFSM(StatesGroup):
    waiting_for_msg = State()


def get_main_menu_text(user_data: dict, header: str = "Главное меню терминала:") -> str:
    sub_end = user_data.get('sub_end_timestamp', 0)
    if sub_end > time.time():
        status_line = f"⏳ <i>Доступ активен: {format_time_left(sub_end)}</i>"
    else:
        status_line = "⚠️ <i>Доступ истёк — продлите в «Мой профиль»</i>"
    return f"{header}\n{status_line}"


async def check_channel_subscription(bot: Bot, user_id: int) -> bool:
    if not CHANNEL_ID or user_id in ADMIN_IDS:
        return True
    try:
        chat_member = await bot.get_chat_member(chat_id=CHANNEL_ID, user_id=user_id)
        return chat_member.status in ["creator", "administrator", "member", "restricted"]
    except Exception:
        return True


async def get_channel_invite_url(bot: Bot) -> str:
    if not CHANNEL_ID:
        return "https://t.me/"
    if CHANNEL_ID.startswith("@"):
        return f"https://t.me/{CHANNEL_ID[1:]}"
    try:
        chat = await bot.get_chat(CHANNEL_ID)
        if chat.username:
            return f"https://t.me/{chat.username}"
        invite = await bot.create_chat_invite_link(CHANNEL_ID)
        return invite.invite_link
    except Exception:
        return "https://t.me/"


@router.message(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext, bot: Bot):
    await state.clear()
    args = message.text.split()[1] if len(message.text.split()) > 1 else None
    user_id = message.from_user.id

    is_subscribed = await check_channel_subscription(bot, user_id)
    if not is_subscribed:
        channel_url = app_state.cached_channel_url or await get_channel_invite_url(bot)
        text = (
            "👋 <b>Добро пожаловать в терминал Spike PRO!</b>\n\n"
            "Для запуска софта и получения бесплатного тестового PRO-доступа "
            "подпишитесь на наш официальный канал.\n\n"
            "После подписки нажмите кнопку <b>🔄 Проверить подписку</b> ниже:"
        )
        await message.answer(text, reply_markup=get_sub_gate_keyboard(channel_url, args))
        return

    referrer_id = int(args[1:]) if (args and re.fullmatch(r"r\d{1,20}", args)) else None

    await get_or_create_user(user_id, bot, referrer_id)
    await message.answer("⚡️ <b>Spike PRO Screener</b>\n\nЗагрузка интерфейса...", reply_markup=ReplyKeyboardRemove())

    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text="⚡️ Погнали (принимаю оферту)", callback_data="accept_dyor"))
    builder.row(types.InlineKeyboardButton(text="📄 Полный текст оферты (.txt)", callback_data="download_offer_doc"))

    await message.answer(get_legal_text(compact=True), reply_markup=builder.as_markup())


@router.callback_query(F.data.startswith("check_sub"))
async def cb_check_sub(callback: types.CallbackQuery, bot: Bot):
    user_id = callback.from_user.id
    if not await check_channel_subscription(bot, user_id):
        await callback.answer("❌ Подписка не обнаружена. Пожалуйста, подпишитесь на канал!", show_alert=True)
        return

    await callback.answer("✅ Подписка подтверждена!", show_alert=False)
    cb_data = callback.data
    referrer_id = None
    if cb_data.startswith("check_sub_r"):
        raw_ref = cb_data.replace("check_sub_r", "")
        if raw_ref.isdigit():
            referrer_id = int(raw_ref)

    await get_or_create_user(user_id, bot, referrer_id)
    try:
        await callback.message.delete()
    except Exception:
        pass

    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text="⚡️ Погнали (принимаю оферту)", callback_data="accept_dyor"))
    builder.row(types.InlineKeyboardButton(text="📄 Полный текст оферты (.txt)", callback_data="download_offer_doc"))

    await callback.message.answer(get_legal_text(compact=True), reply_markup=builder.as_markup())


@router.callback_query(F.data == "download_offer_doc")
async def cb_download_offer_doc(callback: types.CallbackQuery):
    await callback.answer("Формирую документ оферты...")
    doc_path = os.path.join(tempfile.gettempdir(), f"Public_Offer_SpikePRO_{callback.from_user.id}.txt")
    try:
        content = get_full_legal_document_text(app_state.cached_bot_username)
        with open(doc_path, "w", encoding="utf-8") as f:
            f.write(content)
        await callback.message.answer_document(
            document=FSInputFile(doc_path, filename="Public_Offer_SpikePRO.txt"),
            caption="📄 <b>Публичная оферта, Дисклеймер (ФЗ-39) и Политика ПДн (ФЗ-152)</b>"
        )
    finally:
        if os.path.exists(doc_path):
            os.remove(doc_path)


@router.callback_query(F.data == "download_metrics_doc")
async def cb_download_metrics_doc(callback: types.CallbackQuery):
    await callback.answer("Формирую справочник метрик...")
    doc_path = os.path.join(tempfile.gettempdir(), f"Metrics_Guide_SpikePRO_{callback.from_user.id}.txt")
    try:
        content = get_metrics_guide_document_text(app_state.cached_bot_username)
        with open(doc_path, "w", encoding="utf-8") as f:
            f.write(content)
        await callback.message.answer_document(
            document=FSInputFile(doc_path, filename="Metrics_Guide_SpikePRO.txt"),
            caption="📊 <b>Справочник рыночных метрик и методика работы алгоритмов ПО Spike PRO</b>"
        )
    finally:
        if os.path.exists(doc_path):
            os.remove(doc_path)


@router.callback_query(F.data == "accept_dyor")
async def cb_accept_dyor(callback: types.CallbackQuery):
    await callback.answer()
    user_data = await get_or_create_user(callback.from_user.id)
    await record_offer_acceptance(callback.from_user.id)
    is_enabled = bool(user_data.get('alerts_enabled', 1))
    header = "👋 <b>Добро пожаловать в терминал Spike PRO!</b>"
    await callback.message.edit_text(get_main_menu_text(user_data, header), reply_markup=get_main_menu(is_enabled))


@router.callback_query(F.data == "toggle_alerts")
async def cb_toggle_alerts(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    user_data = await get_or_create_user(user_id)
    new_status = 0 if user_data.get('alerts_enabled', 1) else 1
    await update_user_setting(user_id, "alerts_enabled", new_status)
    try:
        await callback.message.edit_text(get_main_menu_text(user_data), reply_markup=get_main_menu(bool(new_status)))
        await callback.answer(f"Уведомления {'включены 🔔' if new_status else 'выключены 🔕'}")
    except Exception:
        await callback.answer()


@router.callback_query(F.data == "back_main")
async def cb_back_main(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    await state.clear()
    user_data = await get_or_create_user(callback.from_user.id)
    is_enabled = bool(user_data.get('alerts_enabled', 1))
    menu_text = get_main_menu_text(user_data)
    try:
        await callback.message.edit_text(menu_text, reply_markup=get_main_menu(is_enabled))
    except Exception:
        await callback.message.delete()
        await callback.message.answer(menu_text, reply_markup=get_main_menu(is_enabled))


@router.callback_query(F.data == "my_profile")
async def cb_my_profile(callback: types.CallbackQuery):
    await callback.answer()
    user_data = await get_or_create_user(callback.from_user.id)
    refs_count = await get_referrals_count(callback.from_user.id)
    sub_end = user_data['sub_end_timestamp']
    if sub_end > time.time():
        rem_str = format_time_left(sub_end)
        sub_status = f"✅ Активен до {datetime.fromtimestamp(sub_end).strftime('%d.%m.%Y %H:%M')}\n⏳ Осталось: <b>{rem_str}</b>"
    else:
        sub_status = "❌ Истек"
    ref_note = f"\n🏷 Скидка на продление: <b>{REF_DISCOUNT_PERCENT}%</b> (по приглашению)" if user_data.get('referrer_id') else ""
    text = (
        f"👤 <b>Профиль трейдера</b>\n\n"
        f"🆔 Ваш ID: <code>{callback.from_user.id}</code>\n"
        f"💎 Статус доступа: <b>{sub_status}</b>{ref_note}\n\n"
        f"👥 Приглашено друзей: <b>{refs_count}</b>"
    )
    await callback.message.edit_text(text, reply_markup=get_profile_menu())


@router.callback_query(F.data == "faq_menu")
async def cb_faq_menu(callback: types.CallbackQuery):
    await callback.answer()
    builder = InlineKeyboardBuilder()
    for key, item in FAQ_ITEMS.items():
        builder.row(types.InlineKeyboardButton(text=item["btn"], callback_data=f"faq_q_{key}"))
    builder.row(types.InlineKeyboardButton(text="◀️ Назад в меню", callback_data="back_main"))

    await callback.message.edit_text(
        "📚 <b>База знаний, оферта и документация ПО</b>\n\nВыберите интересующий раздел ниже:",
        reply_markup=builder.as_markup()
    )


@router.callback_query(F.data.startswith("faq_q_"))
async def cb_faq_answer(callback: types.CallbackQuery):
    await callback.answer()
    key = callback.data.replace("faq_q_", "")
    item = FAQ_ITEMS.get(key)
    if not item:
        return

    body_text = get_legal_text(compact=False) if key == "legal" else item["text"]
    builder = InlineKeyboardBuilder()
    if key == "legal":
        builder.row(types.InlineKeyboardButton(text="📄 Скачать полный текст оферты (.txt)", callback_data="download_offer_doc"))
    elif key == "metrics_doc":
        builder.row(types.InlineKeyboardButton(text="📊 Скачать справочник метрик (.txt)", callback_data="download_metrics_doc"))
    builder.row(types.InlineKeyboardButton(text="◀️ К списку вопросов", callback_data="faq_menu"))
    builder.row(types.InlineKeyboardButton(text="🏠 В главное меню", callback_data="back_main"))
    await callback.message.edit_text(body_text, reply_markup=builder.as_markup(), link_preview_options=LinkPreviewOptions(is_disabled=True))


@router.callback_query(F.data == "send_test_alert")
async def cb_send_test_alert(callback: types.CallbackQuery):
    await callback.answer("Тестовое уведомление сформировано...", show_alert=False)
    ref_param = f"?ref={BYBIT_REF_CODE}" if BYBIT_REF_CODE else ""
    trade_url = f"https://www.bybit.com/trade/usdt/BTCUSDT{ref_param}"
    ref_suffix = f" | 📊 <a href='{html.escape(BYBIT_REF_URL, quote=True)}'>Терминал Bybit</a>" if BYBIT_REF_URL else ""

    test_text = (
        f"🟢 <b>#BTCUSDT</b> <code>+1.65%</code> | <b>Vol:</b> <code>x3.5</code> | <b>OI:</b> <code>+2.40%</code> <i>(ТЕСТ)</i>\n\n"
        f"📌 <b>Динамика:</b> <i>🟢 Набор Long позиций (Приток открытого интереса)</i>\n"
        f"💰 <b>Оборот (5м):</b> <code>$45,200,000</code>\n"
        f"💲 <b>Котировка:</b> <code>68,750.0</code>\n\n"
        f"🔗 <a href='{trade_url}'>Открыть график котировок</a>{ref_suffix}\n"
        f"<i>Справочные данные ПО. Не является ИИР.</i>"
    )
    await callback.message.answer(test_text, link_preview_options=LinkPreviewOptions(is_disabled=True))


@router.callback_query(F.data == "run_diagnostics")
async def cb_run_diagnostics(callback: types.CallbackQuery):
    await callback.answer("Проверка шлюзов...", show_alert=False)
    user_id = callback.from_user.id
    user_data = await get_or_create_user(user_id)
    subs = await get_active_subscribers()
    in_subs = any(s['user_id'] == user_id for s in subs)

    try:
        async with AsyncSession(impersonate="chrome110", proxy=PROXY_URL) as s:
            resp = await s.get("https://api.bybit.com/v5/market/tickers?category=linear", timeout=7)
            if resp.status_code == 200:
                bybit_status = "✅ 200 OK (TLS Chrome + Прокси активны)"
            elif resp.status_code == 403:
                bybit_status = "❌ 403 (Прокси заблокирован биржей)"
            else:
                bybit_status = f"⚠️ HTTP {resp.status_code}"
    except Exception as e:
        bybit_status = f"❌ Ошибка соединения: {type(e).__name__}"

    if not app_state.solana_enabled:
        solana_status = "⏸ Отключен в админке"
    elif not SOLANA_WSS:
        solana_status = "Не задан"
    else:
        sol_http = SOLANA_WSS.replace("wss://", "https://")
        async with aiohttp.ClientSession() as s:
            try:
                async with s.post(sol_http, json={"jsonrpc": "2.0", "id": 1, "method": "getHealth"}, proxy=PROXY_URL, timeout=5) as resp:
                    if resp.status == 200:
                        solana_status = "✅ Ключ валиден (RPC активен)"
                    elif resp.status == 429:
                        solana_status = "❌ 429 (Лимит RPC исчерпан)"
                    else:
                        solana_status = f"⚠️ HTTP {resp.status}"
            except Exception:
                solana_status = "❌ Не удалось связаться с RPC"

    sub_end = user_data.get('sub_end_timestamp', 0)
    sub_diag = f"АКТИВЕН ✅ ({format_time_left(sub_end)})" if sub_end > time.time() else "ИСТЕК ❌"
    proxy_str = PROXY_URL.split('@')[-1] if PROXY_URL and '@' in PROXY_URL else (PROXY_URL or "Не настроен (прямое соединение)")
    diag_text = (
        f"🛠 <b>Отчет о состоянии Spike PRO:</b>\n\n🌐 <b>Сетевой шлюз:</b>\n• <code>{html.escape(proxy_str)}</code>\n\n"
        f"👤 <b>Статус профиля:</b>\n• Режим уведомлений: <b>{'ВКЛЮЧЕН 🔔' if user_data.get('alerts_enabled') else 'ВЫКЛЮЧЕН 🔕'}</b>\n"
        f"• Доступ к ПО: <b>{sub_diag}</b>\n"
        f"• В очереди доставки: <b>{'ДА ✅' if in_subs else 'НЕТ ❌'}</b>\n\n"
        f"📊 <b>Источники данных:</b>\n• Bybit Futures (V5): <b>{bybit_status}</b>\n• Solana Helius RPC: <b>{solana_status}</b>"
    )
    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text="◀️ Назад в меню", callback_data="back_main"))
    await callback.message.edit_text(diag_text, reply_markup=builder.as_markup())


async def _finish_setup(bot: Bot, user_id: int, state: FSMContext):
    user_data = await get_or_create_user(user_id)
    await state.clear()
    is_enabled = bool(user_data.get('alerts_enabled', 1))
    success_text = (
        "✅ <b>Настройки сохранены!</b>\n\n"
        f"• Всплеск объема: <code>{'от ' + str(user_data['min_volume_mult']) + 'x' if user_data['min_volume_mult'] > 0 else 'Отключен 🔕'}</code>\n"
        f"• Импульс цены: <code>{'от ' + str(user_data['min_price_change']) + '%' if user_data['min_price_change'] > 0 else 'Отключен 🔕'}</code>\n"
        f"• Скачок ОИ: <code>{'от ' + str(user_data.get('min_oi_change', 1.2)) + '%' if user_data.get('min_oi_change', 1.2) > 0 else 'Отключен 🔕'}</code>\n"
    )
    await bot.send_message(chat_id=user_id, text=success_text)
    await bot.send_message(chat_id=user_id, text=get_main_menu_text(user_data), reply_markup=get_main_menu(is_enabled))


@router.callback_query(F.data == "start_setup")
async def cb_start_setup(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    await state.clear()
    user_data = await get_or_create_user(callback.from_user.id)
    vol_s = f"{user_data['min_volume_mult']}x" if user_data['min_volume_mult'] > 0 else "Выкл"
    prc_s = f"{user_data['min_price_change']}%" if user_data['min_price_change'] > 0 else "Выкл"
    oi_v = user_data.get('min_oi_change', 1.2)
    oi_s = f"{oi_v}%" if oi_v > 0 else "Выкл"

    text = (
        "⚙️ <b>Настройка фильтров Bybit Futures</b>\n\n"
        f"Текущие пороги:\n"
        f"• Объём: <code>{vol_s}</code> | Цена: <code>{prc_s}</code> | ОИ: <code>{oi_s}</code>\n\n"
        "Выберите готовый пресет в 1 клик или задайте свои значения вручную:"
    )
    await callback.message.edit_text(text, reply_markup=get_presets_keyboard())


@router.callback_query(F.data.in_(FILTER_PRESETS.keys()))
async def cb_apply_preset(callback: types.CallbackQuery, state: FSMContext):
    preset = FILTER_PRESETS[callback.data]
    user_id = callback.from_user.id
    await update_user_setting(user_id, "min_volume_mult", preset["vol"])
    await update_user_setting(user_id, "min_price_change", preset["price"])
    await update_user_setting(user_id, "min_oi_change", preset["oi"])
    await state.clear()

    await callback.answer(f"Пресет «{preset['name']}» применён!", show_alert=False)
    user_data = await get_or_create_user(user_id)
    is_enabled = bool(user_data.get('alerts_enabled', 1))
    header = (
        f"✅ <b>Применён пресет «{preset['name']}»</b>\n"
        f"• Объём: <code>от {preset['vol']}x</code> | Цена: <code>от {preset['price']}%</code> | ОИ: <code>от {preset['oi']}%</code>"
    )
    await callback.message.edit_text(get_main_menu_text(user_data, header), reply_markup=get_main_menu(is_enabled))


@router.callback_query(F.data == "setup_manual")
async def cb_setup_manual(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    await state.clear()
    user_data = await get_or_create_user(callback.from_user.id)
    text = (f"🛠 <b>Ручная настройка (Шаг 1 из 3): Всплеск объема</b>\n\nТекущее: <code>{user_data['min_volume_mult']}x</code>\n\n"
            f"Введите новое значение (рекомендуется <code>3.0</code>) или нажмите «Пропустить».\n<i>(Введите 0, чтобы отключить)</i>:")
    await callback.message.edit_text(text, reply_markup=get_setup_keyboard())
    await state.set_state(UserSettingsFSM.wait_vol)


@router.callback_query(F.data == "skip_setup_step")
async def cb_skip_setup_step(callback: types.CallbackQuery, state: FSMContext, bot: Bot):
    await callback.answer()
    current_state = await state.get_state()
    user_data = await get_or_create_user(callback.from_user.id)

    if current_state == UserSettingsFSM.wait_vol.state:
        text = (f"🛠 <b>Ручная настройка (Шаг 2 из 3): Импульс цены</b>\n\nТекущее: <code>{user_data['min_price_change']}%</code>\n\n"
                f"Введите новое значение в % (рекомендуется <code>1.5</code>) или нажмите «Пропустить».\n<i>(Введите 0, чтобы отключить)</i>:")
        await callback.message.edit_text(text, reply_markup=get_setup_keyboard())
        await state.set_state(UserSettingsFSM.wait_price)
    elif current_state == UserSettingsFSM.wait_price.state:
        text = (f"🛠 <b>Ручная настройка (Шаг 3 из 3): Скачок ОИ</b>\n\nТекущее: <code>{user_data.get('min_oi_change', 1.2)}%</code>\n\n"
                f"Введите новое значение в % (рекомендуется <code>1.2</code>) или нажмите «Пропустить».\n<i>(Введите 0, чтобы отключить)</i>:")
        await callback.message.edit_text(text, reply_markup=get_setup_keyboard())
        await state.set_state(UserSettingsFSM.wait_oi)
    elif current_state == UserSettingsFSM.wait_oi.state:
        await callback.message.delete()
        await _finish_setup(bot, callback.from_user.id, state)


@router.message(UserSettingsFSM.wait_vol)
async def process_step_vol(message: types.Message, state: FSMContext):
    if not message.text:
        return await message.answer("❌ Введите число текстом:", reply_markup=get_setup_keyboard())
    try:
        val = float(message.text.replace(',', '.'))
        if val < 0.0:
            raise ValueError
        await update_user_setting(message.from_user.id, "min_volume_mult", val)
        user_data = await get_or_create_user(message.from_user.id)
        text = (f"🛠 <b>Ручная настройка (Шаг 2 из 3): Импульс цены</b>\n\nТекущее: <code>{user_data['min_price_change']}%</code>\n\n"
                f"Введите новое значение в % (рекомендуется <code>1.5</code>) или нажмите «Пропустить».\n<i>(Введите 0, чтобы отключить)</i>:")
        await message.answer(text, reply_markup=get_setup_keyboard())
        await state.set_state(UserSettingsFSM.wait_price)
    except ValueError:
        await message.answer("❌ Введите положительное число или 0:", reply_markup=get_setup_keyboard())


@router.message(UserSettingsFSM.wait_price)
async def process_step_price(message: types.Message, state: FSMContext):
    if not message.text:
        return await message.answer("❌ Введите число текстом:", reply_markup=get_setup_keyboard())
    try:
        val = float(message.text.replace(',', '.'))
        if val < 0.0:
            raise ValueError
        await update_user_setting(message.from_user.id, "min_price_change", val)
        user_data = await get_or_create_user(message.from_user.id)
        text = (f"🛠 <b>Ручная настройка (Шаг 3 из 3): Скачок ОИ</b>\n\nТекущее: <code>{user_data.get('min_oi_change', 1.2)}%</code>\n\n"
                f"Введите новое значение в % (рекомендуется <code>1.2</code>) или нажмите «Пропустить».\n<i>(Введите 0, чтобы отключить)</i>:")
        await message.answer(text, reply_markup=get_setup_keyboard())
        await state.set_state(UserSettingsFSM.wait_oi)
    except ValueError:
        await message.answer("❌ Введите положительное число или 0:", reply_markup=get_setup_keyboard())


@router.message(UserSettingsFSM.wait_oi)
async def process_step_oi(message: types.Message, state: FSMContext, bot: Bot):
    if not message.text:
        return await message.answer("❌ Введите число текстом:", reply_markup=get_setup_keyboard())
    try:
        val = float(message.text.replace(',', '.'))
        if val < 0.0:
            raise ValueError
        await update_user_setting(message.from_user.id, "min_oi_change", val)
        await _finish_setup(bot, message.from_user.id, state)
    except ValueError:
        await message.answer("❌ Введите положительное число или 0:", reply_markup=get_setup_keyboard())


@router.callback_query(F.data == "blacklist_menu")
async def cb_blacklist_menu(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    user_data = await get_or_create_user(callback.from_user.id)
    current_bl = user_data.get('blacklist') or ""
    bl_text = html.escape(current_bl) if current_bl else "Пусто (приходят все тикеры)"

    text = (
        f"🔇 <b>Блэклист тикеров</b>\n\n"
        f"Укажите тикеры, по которым <b>НЕ хотите</b> получать уведомления.\n\n"
        f"Текущий блэклист: <code>{bl_text}</code>\n\n"
        f"Отправьте список тикеров через пробел или запятую (напр: <code>BTCUSDT ETHUSDT</code>).\n"
        f"<i>Чтобы очистить список, отправьте <code>0</code></i>."
    )
    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text="◀️ Отмена", callback_data="back_main"))
    await callback.message.edit_text(text, reply_markup=builder.as_markup())
    await state.set_state(BlacklistFSM.wait_tickers)


@router.message(BlacklistFSM.wait_tickers)
async def process_blacklist_input(message: types.Message, state: FSMContext):
    if not message.text:
        return await message.answer("❌ Отправьте список тикеров текстом (или <code>0</code> для очистки):")
    await state.clear()
    text = message.text.strip().upper()
    clean_text = "" if text == '0' else ", ".join([t.strip() for t in text.replace(',', ' ').split() if t.strip()])

    await update_user_setting(message.from_user.id, "blacklist", clean_text)
    user_data = await get_or_create_user(message.from_user.id)
    is_enabled = bool(user_data.get('alerts_enabled', 1))

    header = f"✅ <b>Блэклист обновлен!</b>\nИсключения: <code>{html.escape(clean_text) or 'Пусто'}</code>"
    await message.answer(get_main_menu_text(user_data, header), reply_markup=get_main_menu(is_enabled))


@router.callback_query(F.data == "feedback_start")
async def cb_feedback_start(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text="◀️ Отмена", callback_data="back_main"))
    await callback.message.edit_text(
        "💬 <b>Поддержка и обращения</b>\n\nОпишите вопрос по работе ПО, чекам или оплате одним сообщением.",
        reply_markup=builder.as_markup()
    )
    await state.set_state(FeedbackFSM.waiting_for_msg)


@router.message(FeedbackFSM.waiting_for_msg)
async def process_feedback_msg(message: types.Message, state: FSMContext, bot: Bot):
    await state.clear()
    user_data = await get_or_create_user(message.from_user.id)
    for adm in ADMIN_IDS:
        if adm <= 0:
            continue
        try:
            info_text = (f"📩 <b>Новое обращение</b>\nОт: @{message.from_user.username or 'Без_юзернейма'}\nID: <code>{message.from_user.id}</code>\n\n"
                         f"<i>💡 Чтобы ответить, сделайте Reply (Ответить) на это сообщение.</i>")
            msg_content = message.text or message.caption or ""
            if msg_content and not (message.photo or message.document or message.video):
                await bot.send_message(adm, f"{info_text}\n\n<b>Текст:</b>\n{message.html_text}")
            else:
                await bot.send_message(adm, f"{info_text}\n\n<b>Подпись:</b>\n{html.escape(msg_content)}" if msg_content else info_text)
                await bot.copy_message(chat_id=adm, from_chat_id=message.chat.id, message_id=message.message_id)
        except Exception:
            pass
    header = "✅ Ваше сообщение доставлено в поддержку!"
    await message.answer(get_main_menu_text(user_data, header), reply_markup=get_main_menu(bool(user_data.get('alerts_enabled', 1))))