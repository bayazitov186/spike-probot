import logging
import time
from urllib.parse import urlencode

from aiohttp import web
from aiogram import Bot, Router, F, types
from aiogram.types import LinkPreviewOptions
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import (
    state as app_state, TARIFFS, ADMIN_IDS,
    REF_DISCOUNT_PERCENT, REF_BONUS_DAYS,
    PRODAMUS_URL, PRODAMUS_SECRET_KEY,
    ENABLE_CRYPTO_PAY, CRYPTO_PAY_TOKEN
)
from database import (
    get_or_create_user, record_offer_acceptance,
    claim_fiat_and_add_sub, claim_invoice_and_add_sub, format_time_left
)
from keyboards import get_main_menu, get_profile_menu
from handlers.user import get_main_menu_text

logger = logging.getLogger("SpikePRO.Payments")
router = Router()

crypto = None
if ENABLE_CRYPTO_PAY and CRYPTO_PAY_TOKEN:
    try:
        from aiocryptopay import AioCryptoPay, Networks
        crypto = AioCryptoPay(token=CRYPTO_PAY_TOKEN, network=Networks.MAIN_NET)
    except Exception as e:
        logger.error(f"Ошибка инициализации CryptoPay: {e}")


def calc_tariff_prices(tariff: dict, has_discount: bool) -> tuple[int, float]:
    base_rub = tariff['price_rub']
    base_usdt = tariff['price_usdt']
    if has_discount:
        final_rub = max(1, int(round(base_rub * (1.0 - REF_DISCOUNT_PERCENT / 100.0))))
        final_usdt = round(base_usdt * (1.0 - REF_DISCOUNT_PERCENT / 100.0), 2)
        return final_rub, final_usdt
    return base_rub, base_usdt


@router.callback_query(F.data == "buy_sub")
async def cb_buy_sub(callback: types.CallbackQuery):
    await callback.answer()
    user_data = await get_or_create_user(callback.from_user.id)
    has_discount = bool(user_data.get('referrer_id'))

    builder = InlineKeyboardBuilder()
    for tariff_id, data in TARIFFS.items():
        final_rub, _ = calc_tariff_prices(data, has_discount)
        disc_tag = f" (-{REF_DISCOUNT_PERCENT}%)" if has_discount else ""
        btn_text = f"💎 {data['name']} — {final_rub:,} ₽{disc_tag}".replace(",", " ")
        builder.row(types.InlineKeyboardButton(text=btn_text, callback_data=f"tariff_{tariff_id}"))

    builder.row(types.InlineKeyboardButton(text="📄 Публичная оферта", callback_data="faq_q_legal"))
    builder.row(types.InlineKeyboardButton(text="◀️ Назад", callback_data="my_profile"))

    discount_notice = f"\n🏷 <i>Для вас действует скидка {REF_DISCOUNT_PERCENT}% по приглашению!</i>\n" if has_discount else "\n"
    await callback.message.edit_text(
        f"<b>Выберите тариф доступа к ПО Spike PRO:</b>{discount_notice}\n"
        f"🧾 <i>Оплата производится в рублях РФ (карты РФ, СБП) с автоматическим формированием фискального чека ФНС «Мой налог».</i>\n"
        f"⚖️ <i>Оплачивая тариф, вы подтверждаете акцепт Публичной оферты.</i>",
        reply_markup=builder.as_markup()
    )


@router.callback_query(F.data.startswith("tariff_"))
async def cb_select_payment_method(callback: types.CallbackQuery):
    await callback.answer()
    tariff_id = callback.data.split("_", 1)[1]
    tariff = TARIFFS.get(tariff_id)
    if not tariff:
        return await callback.answer("Тариф не найден.", show_alert=True)

    user_data = await get_or_create_user(callback.from_user.id)
    has_discount = bool(user_data.get('referrer_id'))
    final_rub, final_usdt = calc_tariff_prices(tariff, has_discount)
    rub_str = f"{final_rub:,}".replace(",", " ")

    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(
        text=f"💳 Оплатить {rub_str} ₽ (Карта РФ / СБП)",
        callback_data=f"payrub_{tariff_id}"
    ))

    if ENABLE_CRYPTO_PAY and crypto:
        builder.row(types.InlineKeyboardButton(
            text=f"🌐 Оплатить {final_usdt} USDT (CryptoBot)",
            callback_data=f"payusdt_{tariff_id}"
        ))

    builder.row(types.InlineKeyboardButton(text="◀️ Назад к тарифам", callback_data="buy_sub"))

    discount_text = f"\n🏷 <i>Применена скидка {REF_DISCOUNT_PERCENT}%!</i>" if has_discount else ""
    await callback.message.edit_text(
        f"💳 <b>Оформление доступа к ПО Spike PRO</b>\n\n"
        f"Тариф: <b>{tariff['name']}</b> ({tariff['days']} дн.){discount_text}\n"
        f"Сумма к оплате: <b>{rub_str} ₽</b>\n"
        f"Наименование в чеке: <i>Предоставление удалённого доступа к информационно-аналитическому ПО Spike PRO</i>\n\n"
        f"Нажмите кнопку ниже для перехода к оплате:",
        reply_markup=builder.as_markup()
    )


@router.callback_query(F.data.startswith("payrub_"))
async def cb_pay_rub(callback: types.CallbackQuery, bot: Bot):
    await callback.answer()
    tariff_id = callback.data.split("_", 1)[1]
    tariff = TARIFFS.get(tariff_id)
    if not tariff:
        return await callback.answer("Тариф не найден.", show_alert=True)

    user_id = callback.from_user.id
    user_data = await get_or_create_user(user_id)
    await record_offer_acceptance(user_id)
    has_discount = bool(user_data.get('referrer_id'))
    final_rub, _ = calc_tariff_prices(tariff, has_discount)
    rub_str = f"{final_rub:,}".replace(",", " ")

    if not PRODAMUS_URL or not PRODAMUS_URL.startswith(("http://", "https://")):
        for adm in ADMIN_IDS:
            if adm > 0:
                try:
                    await bot.send_message(
                        adm,
                        f"💳 <b>Заявка на оплату в рублях</b>\n"
                        f"Пользователь: @{callback.from_user.username or 'Без_юзернейма'} (<code>{user_id}</code>)\n"
                        f"Тариф: <b>{tariff['name']}</b> — <b>{rub_str} ₽</b>\n\n"
                        f"Для зачисления с учётом в лимите НПД используйте «🎁 Выдать PRO» и отправьте:\n"
                        f"<code>{user_id} {tariff['days']} {final_rub}</code>"
                    )
                except Exception:
                    pass

        builder = InlineKeyboardBuilder()
        builder.row(types.InlineKeyboardButton(text="💬 Написать в поддержку", callback_data="feedback_start"))
        builder.row(types.InlineKeyboardButton(text="◀️ Назад в профиль", callback_data="my_profile"))

        await callback.message.edit_text(
            f"⏳ <b>Платёжный шлюз подключается</b>\n\n"
            f"Выбран тариф: <b>{tariff['name']}</b> (<b>{rub_str} ₽</b>).\n"
            f"Сейчас завершается подключение приёма карт РФ и СБП с автоматической выдачей чеков «Мой налог».\n\n"
            f"Ваша заявка уже передана администратору — напишите в поддержку для быстрого подключения.",
            reply_markup=builder.as_markup()
        )
        return

    order_id = f"sp_{user_id}_{tariff_id}_{int(time.time())}"
    query_params = urlencode({
        "order_id": order_id,
        "products[0][price]": final_rub,
        "products[0][quantity]": 1,
        "products[0][name]": f"Предоставление удалённого доступа к информационно-аналитическому ПО Spike PRO ({tariff['days']} дн.)",
        "customer_extra": f"{user_id}:{tariff_id}:{final_rub}",
        "do": "pay"
    })
    separator = "&" if "?" in PRODAMUS_URL else "?"
    pay_link = f"{PRODAMUS_URL}{separator}{query_params}"

    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text=f"💳 Оплатить {rub_str} ₽ (СБП / Карта РФ)", url=pay_link))
    builder.row(types.InlineKeyboardButton(text="◀️ Назад", callback_data=f"tariff_{tariff_id}"))

    await callback.message.edit_text(
        f"🧾 <b>Счёт сформирован</b>\n\n"
        f"Тариф: <b>{tariff['name']}</b>\n"
        f"Сумма: <b>{rub_str} ₽</b>\n\n"
        f"После оплаты фискальный чек ФНС «Мой налог» придёт на ваш контакт, а доступ к ПО активируется автоматически.",
        reply_markup=builder.as_markup()
    )


async def prodamus_webhook_handler(request: web.Request) -> web.Response:
    bot: Bot = request.app["bot"]
    try:
        post_data = await request.post()
        payment_status = str(post_data.get("payment_status", "")).lower()
        order_id = str(post_data.get("order_id", "")).strip()
        customer_extra = str(post_data.get("customer_extra", "")).strip()
        sum_val = float(post_data.get("sum", 0) or 0)

        if payment_status != "success" or not order_id:
            return web.Response(text="IGNORED", status=200)

        user_id, tariff_id = 0, ""
        if ":" in customer_extra:
            parts = customer_extra.split(":")
            if parts[0].isdigit() and parts[1] in TARIFFS:
                user_id = int(parts[0])
                tariff_id = parts[1]
        elif order_id.startswith("sp_"):
            m_parts = order_id.split("_")
            if len(m_parts) >= 4 and m_parts[1].isdigit():
                user_id = int(m_parts[1])
                tariff_id = f"{m_parts[2]}_{m_parts[3]}"

        if not user_id or tariff_id not in TARIFFS:
            return web.Response(text="BAD_ORDER", status=400)

        tariff = TARIFFS[tariff_id]
        amount_rub = sum_val if sum_val > 0 else tariff["price_rub"]
        is_first = await claim_fiat_and_add_sub(order_id, user_id, tariff["days"], amount_rub, provider="prodamus")

        if is_first:
            user_data = await get_or_create_user(user_id)
            rem_str = format_time_left(user_data["sub_end_timestamp"])
            try:
                await bot.send_message(
                    chat_id=user_id,
                    text=(
                        f"🎉 <b>Оплата в рублях подтверждена!</b>\n\n"
                        f"Доступ к ПО Spike PRO продлён на <b>{tariff['days']} дн.</b>\n"
                        f"⏳ Активно: <b>{rem_str}</b>\n"
                        f"🧾 Фискальный чек ФНС «Мой налог» направлен на указанный при оплате контакт."
                    ),
                    reply_markup=get_profile_menu()
                )
            except Exception:
                pass

        return web.Response(text="OK", status=200)
    except Exception as e:
        logger.error(f"Ошибка обработки вебхука Prodamus: {e}")
        return web.Response(text="ERROR", status=500)


@router.callback_query(F.data.startswith("payusdt_"))
async def cb_create_invoice(callback: types.CallbackQuery):
    if not ENABLE_CRYPTO_PAY or not crypto:
        return await callback.answer("Оплата в криптовалюте отключена в соответствии с законодательством РФ.", show_alert=True)

    await callback.answer()
    tariff_id = callback.data.split("_", 1)[1]
    tariff = TARIFFS.get(tariff_id)
    if not tariff:
        return await callback.answer("Тариф не найден.", show_alert=True)

    user_data = await get_or_create_user(callback.from_user.id)
    has_discount = bool(user_data.get('referrer_id'))
    _, final_price = calc_tariff_prices(tariff, has_discount)

    try:
        invoice = await crypto.create_invoice(
            asset='USDT',
            amount=final_price,
            description=f"Доступ к ПО Spike PRO ({tariff['name']})"
        )
        builder = InlineKeyboardBuilder()
        builder.row(types.InlineKeyboardButton(text="💳 Оплатить через CryptoBot", url=invoice.bot_invoice_url))
        builder.row(types.InlineKeyboardButton(text="🔄 Проверить оплату", callback_data=f"check_{invoice.invoice_id}_{tariff_id}"))
        builder.row(types.InlineKeyboardButton(text="◀️ Назад", callback_data=f"tariff_{tariff_id}"))

        await callback.message.edit_text(
            f"🧾 <b>Счет сформирован</b>\n\nТариф: <b>{tariff['name']}</b>\nСумма: <b>{final_price} USDT</b>",
            reply_markup=builder.as_markup()
        )
    except Exception as e:
        logger.error(f"Ошибка при создании счета: {e}")
        await callback.answer("Ошибка при создании счета.", show_alert=True)


@router.callback_query(F.data.startswith("check_"))
async def cb_check_payment(callback: types.CallbackQuery):
    if not ENABLE_CRYPTO_PAY or not crypto:
        return await callback.answer("Модуль CryptoPay отключен.", show_alert=True)

    parts = callback.data.split("_", 2)
    if len(parts) != 3 or not parts[1].isdigit() or parts[2] not in TARIFFS:
        return await callback.answer("Некорректные данные счета.", show_alert=True)

    invoice_id = int(parts[1])
    tariff = TARIFFS[parts[2]]

    if invoice_id in app_state.processing_invoices:
        return await callback.answer("⏳ Проверка...", show_alert=False)
    app_state.processing_invoices.add(invoice_id)
    try:
        result = await crypto.get_invoices(invoice_ids=invoice_id)
        if not result:
            return await callback.answer("Счет не найден.", show_alert=True)
        invoice = result[0] if isinstance(result, list) else result

        if invoice.status == 'paid':
            is_first = await claim_invoice_and_add_sub(invoice_id, callback.from_user.id, tariff['days'])
            user_data = await get_or_create_user(callback.from_user.id)
            if is_first:
                rem_str = format_time_left(user_data['sub_end_timestamp'])
                await callback.message.edit_text(
                    f"🎉 <b>Оплата подтверждена!</b>\nПродлено на {tariff['days']} дней.\n⏳ Активно: <b>{rem_str}</b>",
                    reply_markup=get_profile_menu()
                )
            else:
                await callback.answer("✅ Уже зачислен.", show_alert=True)
                await callback.message.edit_text(get_main_menu_text(user_data), reply_markup=get_main_menu(bool(user_data.get('alerts_enabled', 1))))
        elif invoice.status == 'active':
            await callback.answer("⏳ Платеж пока не поступил.", show_alert=True)
        else:
            await callback.answer("⚠️ Счет истек или отменен.", show_alert=True)
    except Exception as e:
        logger.error(f"Ошибка проверки инвойса {invoice_id}: {e}")
        await callback.answer("⚠️ Ошибка связи.", show_alert=True)
    finally:
        app_state.processing_invoices.discard(invoice_id)


@router.callback_query(F.data == "ref_menu")
async def cb_ref_menu(callback: types.CallbackQuery):
    await callback.answer()
    ref_link = f"https://t.me/{app_state.cached_bot_username}?start=r{callback.from_user.id}"

    text = (
        f"🎁 <b>Партнёрская программа ПО Spike PRO</b>\n\n"
        f"• Вы и приглашённый пользователь получаете <b>+{REF_BONUS_DAYS} дня</b> доступа к ПО.\n"
        f"• Приглашённый пользователь получает скидка <b>{REF_DISCOUNT_PERCENT}%</b> на подписку!\n\n"
        f"🔗 <b>Ваша пригласительная ссылка:</b>\n"
        f"👉 <a href='{ref_link}'><b>Нажмите для перехода по ссылке</b></a>\n\n"
        f"<i>(Или скопируйте для пересылки: <code>{ref_link}</code>)</i>"
    )
    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text="🚀 Проверить мою ссылку", url=ref_link))
    builder.row(types.InlineKeyboardButton(text="◀️ Назад", callback_data="my_profile"))
    await callback.message.edit_text(text, reply_markup=builder.as_markup(), link_preview_options=LinkPreviewOptions(is_disabled=True))