import asyncio
import logging
import time

import aiosqlite
from aiogram import Bot, types
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import DB_PATH, EXPIRY_REMINDER_HOURS
from database import format_time_left
from workers.bybit_screener import MarketScanner

logger = logging.getLogger("SpikePRO.Tracker")


async def check_expiring_subscriptions(bot: Bot, now: float):
    try:
        threshold = now + EXPIRY_REMINDER_HOURS * 3600
        async with aiosqlite.connect(DB_PATH, timeout=30) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT user_id, sub_end_timestamp FROM users WHERE sub_end_timestamp > ? AND sub_end_timestamp <= ? AND expiry_notified = 0 AND alerts_enabled = 1",
                (now, threshold)
            ) as cur:
                expiring_users = [dict(r) for r in await cur.fetchall()]

            if not expiring_users:
                return

            ids = [u['user_id'] for u in expiring_users]
            placeholders = ",".join("?" for _ in ids)
            await db.execute(f"UPDATE users SET expiry_notified = 1 WHERE user_id IN ({placeholders})", ids)
            await db.commit()

        builder = InlineKeyboardBuilder()
        builder.row(types.InlineKeyboardButton(text="💎 Продлить PRO-доступ", callback_data="buy_sub"))
        kb = builder.as_markup()

        for u in expiring_users:
            rem_str = format_time_left(u['sub_end_timestamp'])
            msg_text = (
                f"⏳ <b>Напоминание Spike PRO</b>\n\n"
                f"До окончания вашего доступа осталось: <b>{rem_str}</b>.\n"
                f"Чтобы получение аналитики не прерывалось, вы можете продлить подписку заранее."
            )
            try:
                await bot.send_message(chat_id=u['user_id'], text=msg_text, reply_markup=kb)
            except Exception:
                pass
            finally:
                await asyncio.sleep(0.05)
    except Exception as e:
        logger.error(f"Ошибка проверки истекающих подписок: {e}")


async def performance_tracker_worker(bot: Bot):
    logger.info("Модуль хронологического авто-трекинга точности (1m свечи) запущен.")
    scanner = MarketScanner()
    try:
        while True:
            try:
                await asyncio.sleep(60)
                now = time.time()
                await check_expiring_subscriptions(bot, now)
                session = await scanner.get_session()

                async with aiosqlite.connect(DB_PATH, timeout=30) as db:
                    await db.execute(
                        "UPDATE signals_history SET result = 'EXPIRED' WHERE result = 'PENDING' AND created_at < ?",
                        (now - 21600,)
                    )
                    await db.commit()

                    db.row_factory = aiosqlite.Row
                    async with db.execute("""
                        SELECT * FROM signals_history 
                        WHERE result = 'PENDING' AND created_at >= ?
                    """, (now - 21600,)) as cur:
                        signals = [dict(r) for r in await cur.fetchall()]

                for s in signals:
                    try:
                        age_sec = now - s['created_at']
                        symbol = s['symbol']
                        entry = s['entry_price']
                        side = s['side']
                        start_ms = ((int(s['created_at']) // 60) + 1) * 60 * 1000

                        if age_sec >= 960 and not s['checked_15m']:
                            params = {
                                "category": "linear", "symbol": symbol, "interval": "1",
                                "start": start_ms, "end": start_ms + 900 * 1000, "limit": 15
                            }
                            resp = await session.get("https://api.bybit.com/v5/market/kline", params=params, timeout=6)
                            if resp.status_code == 200:
                                body = resp.json()
                                klines = (body.get('result') or {}).get('list') or [] if body.get('retCode') == 0 else []
                                if klines:
                                    highs = [float(k[2]) for k in klines]
                                    lows = [float(k[3]) for k in klines]
                                    max_h, min_l = max(highs), min(lows)

                                    if side == "LONG":
                                        pnl_h = ((max_h - entry) / entry) * 100
                                        pnl_l = ((min_l - entry) / entry) * 100
                                    else:
                                        pnl_h = ((entry - min_l) / entry) * 100
                                        pnl_l = ((entry - max_h) / entry) * 100

                                    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
                                        await db.execute("""
                                            UPDATE signals_history 
                                            SET checked_15m = 1, max_profit_15m = ?, max_loss_15m = ? 
                                            WHERE id = ?
                                        """, (round(pnl_h, 2), round(pnl_l, 2), s['id']))
                                        await db.commit()
                            await asyncio.sleep(0.15)

                        if age_sec >= 3660 and not s['checked_1h']:
                            params = {
                                "category": "linear", "symbol": symbol, "interval": "1",
                                "start": start_ms, "end": start_ms + 3600 * 1000, "limit": 60
                            }
                            resp = await session.get("https://api.bybit.com/v5/market/kline", params=params, timeout=6)
                            if resp.status_code == 200:
                                body = resp.json()
                                raw_klines = (body.get('result') or {}).get('list') or [] if body.get('retCode') == 0 else []
                                if raw_klines:
                                    chrono_klines = list(reversed(raw_klines))

                                    max_pnl = 0.0
                                    final_res = "PENDING"
                                    TP_TARGET = 1.5
                                    SL_TARGET = -2.5

                                    for k in chrono_klines:
                                        k_high, k_low = float(k[2]), float(k[3])
                                        if side == "LONG":
                                            step_profit = ((k_high - entry) / entry) * 100
                                            step_loss = ((k_low - entry) / entry) * 100
                                        else:
                                            step_profit = ((entry - k_low) / entry) * 100
                                            step_loss = ((entry - k_high) / entry) * 100

                                        if final_res != "LOSS" and step_profit > max_pnl:
                                            max_pnl = step_profit

                                        if final_res == "PENDING":
                                            if step_loss <= SL_TARGET:
                                                final_res = "LOSS"
                                            elif step_profit >= TP_TARGET:
                                                final_res = "WIN"

                                    if final_res == "PENDING":
                                        final_res = "BE" if max_pnl >= 0.7 else "LOSS"

                                    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
                                        await db.execute("""
                                            UPDATE signals_history 
                                            SET checked_1h = 1, max_profit_1h = ?, result = ? 
                                            WHERE id = ?
                                        """, (round(max_pnl, 2), final_res, s['id']))
                                        await db.commit()
                            await asyncio.sleep(0.15)
                    except Exception as loop_err:
                        logger.warning(f"Ошибка проверки сигнала ID {s.get('id')}: {loop_err}")
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.error(f"Ошибка в performance_tracker: {e}")
    except asyncio.CancelledError:
        pass
    finally:
        await scanner.close()