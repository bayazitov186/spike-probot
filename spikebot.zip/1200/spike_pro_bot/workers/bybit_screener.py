import asyncio
import html
import logging
import time
from typing import Dict, List, Optional

from aiogram import Bot
from aiogram.types import LinkPreviewOptions
from curl_cffi.requests import AsyncSession

from config import (
    state as app_state, PROXY_URL, CHANNEL_ID, BYBIT_REF_CODE, BYBIT_REF_URL,
    CHECK_INTERVAL_SEC, TIMEFRAME, TOP_PAIRS_LIMIT, ALERT_COOLDOWN_SEC,
    CONCURRENT_REQUESTS_LIMIT, EXCLUDED_SYMBOLS,
    CHANNEL_MIN_VOL, CHANNEL_MIN_PRICE_CHANGE, CHANNEL_MAX_PRICE_CHANGE,
    CHANNEL_MIN_OI_CHANGE, CHANNEL_DAILY_LIMIT, CHANNEL_POST_INTERVAL_SEC
)
from database import log_signal_to_db, get_active_subscribers

logger = logging.getLogger("SpikePRO.Bybit")


class MarketScanner:
    def __init__(self):
        self.base_url = "https://api.bybit.com"
        self.session: Optional[AsyncSession] = None
        self.oi_history: Dict[str, List[tuple]] = {}
        self.semaphore = asyncio.Semaphore(CONCURRENT_REQUESTS_LIMIT)

    async def get_session(self) -> AsyncSession:
        if self.session is None:
            self.session = AsyncSession(impersonate="chrome110", proxy=PROXY_URL)
        return self.session

    async def fetch_top_usdt_pairs(self) -> List[str]:
        try:
            session = await self.get_session()
            resp = await session.get(f"{self.base_url}/v5/market/tickers", params={"category": "linear"}, timeout=8)
            if resp.status_code != 200:
                return []
            tickers = (resp.json().get("result") or {}).get("list") or []
            valid_pairs = [
                t for t in tickers
                if t.get("symbol", "").endswith("USDT") and t.get("symbol") not in EXCLUDED_SYMBOLS and "-" not in t.get("symbol")
            ]
            valid_pairs.sort(key=lambda x: float(x.get("turnover24h") or 0), reverse=True)
            return [i["symbol"] for i in valid_pairs[:TOP_PAIRS_LIMIT]]
        except Exception:
            return []

    async def fetch_klines(self, symbol: str):
        try:
            session = await self.get_session()
            params = {"category": "linear", "symbol": symbol, "interval": TIMEFRAME, "limit": 21}
            resp = await session.get(f"{self.base_url}/v5/market/kline", params=params, timeout=6)
            if resp.status_code == 200:
                body = resp.json()
                if body.get("retCode") == 0:
                    return list(reversed((body.get("result") or {}).get("list") or []))
            return None
        except Exception:
            return None

    async def fetch_oi_pair(self, symbol: str) -> Optional[tuple[float, float]]:
        try:
            session = await self.get_session()
            params = {"category": "linear", "symbol": symbol, "intervalTime": "5min", "limit": 2}
            resp = await session.get(f"{self.base_url}/v5/market/open-interest", params=params, timeout=6)
            if resp.status_code == 200:
                body = resp.json()
                if body.get("retCode") == 0:
                    rows = (body.get("result") or {}).get("list") or []
                    if rows:
                        cur_oi = float(rows[0].get("openInterest") or 0)
                        prev_oi = float(rows[1].get("openInterest") or 0) if len(rows) > 1 else 0.0
                        return cur_oi, prev_oi
            return None
        except Exception:
            return None

    async def analyze_pair(self, symbol: str) -> Optional[dict]:
        async with self.semaphore:
            try:
                klines, oi_pair = await asyncio.gather(self.fetch_klines(symbol), self.fetch_oi_pair(symbol))
                if not klines or oi_pair is None or len(klines) < 21:
                    return None

                current_oi, prev_5m_oi = oi_pair
                prev_candles = klines[-21:-1]
                cur_open, cur_close, cur_turnover = float(klines[-1][1]), float(klines[-1][4]), float(klines[-1][6])
                turnovers = [float(c[6]) for c in prev_candles]
                avg_turnover = sum(turnovers) / len(turnovers) if turnovers else 1.0

                price_change_pct = ((cur_close - cur_open) / cur_open) * 100 if cur_open > 0 else 0
                vol_ratio = cur_turnover / avg_turnover if avg_turnover > 0 else 0

                now_ts = time.time()
                if symbol not in self.oi_history or not self.oi_history[symbol]:
                    self.oi_history[symbol] = []
                    if prev_5m_oi > 0:
                        self.oi_history[symbol].append((now_ts - 295, prev_5m_oi))

                self.oi_history[symbol].append((now_ts, current_oi))
                self.oi_history[symbol] = [x for x in self.oi_history[symbol] if x[0] >= now_ts - 300]

                oldest_oi = self.oi_history[symbol][0][1]
                oi_change_pct = ((current_oi - oldest_oi) / oldest_oi) * 100 if len(self.oi_history[symbol]) > 1 and oldest_oi > 0 else 0.0

                return {
                    "symbol": symbol, "price": cur_close, "price_change": price_change_pct,
                    "vol_ratio": vol_ratio, "current_vol_usdt": cur_turnover,
                    "oi_change": oi_change_pct, "current_oi": current_oi
                }
            except Exception:
                return None

    def cleanup_stale_oi_history(self, now_ts: float):
        stale = [sym for sym, hist in self.oi_history.items() if not hist or (now_ts - hist[-1][0]) > 600]
        for sym in stale:
            del self.oi_history[sym]

    async def close(self):
        if self.session:
            await self.session.close()
            self.session = None


async def dispatch_alert(bot: Bot, sig: dict, subscribers: List[dict], now: float):
    if app_state.emergency_pause:
        return

    price_change = sig['price_change']
    oi_change = sig['oi_change']
    vol_ratio = sig['vol_ratio']

    if oi_change >= 0.8 and price_change >= 1.0:
        market_phase = "🟢 Набор Long позиций (Приток открытого интереса)"
    elif oi_change >= 0.8 and price_change <= -1.0:
        market_phase = "🔴 Набор Short позиций (Приток открытого интереса)"
    elif oi_change <= -0.8 and price_change >= 1.0:
        market_phase = "🚀 Шорт-сквиз (Сокращение коротких позиций)"
    elif oi_change <= -0.8 and price_change <= -1.0:
        market_phase = "⚠️ Лонг-ликвидации (Сокращение длинных позиций)"
    else:
        market_phase = "⚡️ Импульсное изменение объема"

    side_label = "LONG" if price_change >= 0 else "SHORT"
    dot, side_emoji, direction = ("🟢", "🟢 LONG", "+") if price_change >= 0 else ("🔴", "🔴 SHORT", "")
    oi_direction = "+" if oi_change > 0 else ""

    is_valid_setup = (
        vol_ratio >= 3.0 and
        1.2 <= abs(price_change) <= 4.5 and
        oi_change >= 0.8
    )
    if is_valid_setup:
        track_key = f"track_{sig['symbol']}"
        if track_key not in app_state.recent_alerts or (now - app_state.recent_alerts[track_key]) > ALERT_COOLDOWN_SEC:
            app_state.recent_alerts[track_key] = now
            await log_signal_to_db(sig, side_label, market_phase)

    if subscribers:
        overheat_warn = "\n⚠️ <b>Примечание:</b> <i>Высокая амплитуда свечи (&gt;4.5%).</i>" if abs(price_change) > 4.5 else ""
        ref_param = f"?ref={BYBIT_REF_CODE}" if BYBIT_REF_CODE else ""
        trade_url = f"https://www.bybit.com/trade/usdt/{sig['symbol']}{ref_param}"
        ref_suffix = f" | 📊 <a href='{html.escape(BYBIT_REF_URL, quote=True)}'>Терминал Bybit</a>" if BYBIT_REF_URL else ""

        for sub in subscribers:
            uid = sub['user_id']
            user_blacklist = sub.get('blacklist') or ""
            if user_blacklist:
                blacklisted_tickers = [t.strip().upper() for t in user_blacklist.split(',') if t.strip()]
                if sig['symbol'].upper() in blacklisted_tickers:
                    continue

            is_vol_match = True if sub['min_volume_mult'] <= 0 else (vol_ratio >= sub['min_volume_mult'])
            is_price_match = True if sub['min_price_change'] <= 0 else (abs(price_change) >= sub['min_price_change'])
            user_oi_thresh = sub.get('min_oi_change', 1.2)
            is_oi_match = True if user_oi_thresh <= 0 else (abs(oi_change) >= user_oi_thresh)

            if is_vol_match and is_price_match and is_oi_match:
                cache_key = f"{uid}_{sig['symbol']}"
                if cache_key in app_state.recent_alerts and (now - app_state.recent_alerts[cache_key]) < ALERT_COOLDOWN_SEC:
                    continue

                app_state.recent_alerts[cache_key] = now
                text = (
                    f"{dot} <b>#{sig['symbol']}</b> <code>{direction}{price_change:.2f}%</code> | "
                    f"<b>Vol:</b> <code>x{vol_ratio:.1f}</code> | <b>OI:</b> <code>{oi_direction}{oi_change:.2f}%</code>\n\n"
                    f"📌 <b>Динамика:</b> <i>{market_phase}</i>{overheat_warn}\n"
                    f"💰 <b>Оборот (5м):</b> <code>${sig['current_vol_usdt']:,.0f}</code>\n"
                    f"💲 <b>Котировка:</b> <code>{sig['price']}</code>\n\n"
                    f"🔗 <a href='{trade_url}'>Открыть график котировок</a>{ref_suffix}\n"
                    f"<i>Справочные данные ПО. Не является ИИР.</i>"
                )
                try:
                    await bot.send_message(chat_id=uid, text=text, link_preview_options=LinkPreviewOptions(is_disabled=True))
                except Exception:
                    pass
                finally:
                    await asyncio.sleep(0.04)

    is_channel_quality_signal = (
        vol_ratio >= CHANNEL_MIN_VOL and
        CHANNEL_MIN_PRICE_CHANGE <= abs(price_change) <= CHANNEL_MAX_PRICE_CHANGE and
        oi_change >= CHANNEL_MIN_OI_CHANGE
    )

    if CHANNEL_ID and is_channel_quality_signal:
        current_day = time.strftime("%Y-%m-%d", time.localtime(now))
        stored_day = time.strftime("%Y-%m-%d", time.localtime(app_state.channel_day_timestamp))
        if current_day != stored_day:
            app_state.channel_posts_today = 0
            app_state.channel_day_timestamp = now
            app_state.recent_channel_alerts.clear()

        chan_cache_key = f"channel_{sig['symbol']}"
        time_since_ticker = now - app_state.recent_channel_alerts.get(chan_cache_key, 0)
        time_since_last_channel_post = now - app_state.channel_last_post_time

        if (app_state.channel_posts_today < CHANNEL_DAILY_LIMIT and
            time_since_last_channel_post >= CHANNEL_POST_INTERVAL_SEC and
            time_since_ticker >= 14400):

            app_state.recent_channel_alerts[chan_cache_key] = now
            app_state.channel_last_post_time = now
            app_state.channel_posts_today += 1

            chan_text = (
                f"📊 <b>#{sig['symbol']}</b> {side_emoji} (Мониторинг #{app_state.channel_posts_today}/{CHANNEL_DAILY_LIMIT})\n\n"
                f"📌 <b>Динамика:</b> <i>{market_phase}</i>\n\n"
                f"<b>Объем:</b> <code>x{vol_ratio:.1f}</code>\n"
                f"<b>ОИ:</b> <code>{oi_direction}{oi_change:.2f}%</code>\n"
                f"<b>Цена:</b> <code>{direction}{price_change:.2f}%</code>\n\n"
                f"🤖 <a href='https://t.me/{app_state.cached_bot_username}'>Настроить фильтры в ПО Spike PRO</a>\n"
                f"<i>Информация носит справочный характер. Не ИИР.</i>"
            )
            try:
                await bot.send_message(chat_id=CHANNEL_ID, text=chan_text, link_preview_options=LinkPreviewOptions(is_disabled=True))
            except Exception as e:
                logger.error(f"Ошибка публикации в канал: {e}")


async def screener_worker(bot: Bot):
    scanner = MarketScanner()
    try:
        while True:
            try:
                if not app_state.emergency_pause:
                    pairs = await scanner.fetch_top_usdt_pairs()
                    now = time.time()
                    stale_keys = [k for k, v in app_state.recent_alerts.items() if (now - v) > ALERT_COOLDOWN_SEC]
                    for k in stale_keys:
                        del app_state.recent_alerts[k]

                    stale_chan = [k for k, v in app_state.recent_channel_alerts.items() if (now - v) > 28800]
                    for k in stale_chan:
                        del app_state.recent_channel_alerts[k]

                    scanner.cleanup_stale_oi_history(now)

                    if pairs:
                        results = await asyncio.gather(*(scanner.analyze_pair(sym) for sym in pairs), return_exceptions=True)
                        subscribers = await get_active_subscribers()
                        for sig in results:
                            if isinstance(sig, dict):
                                await dispatch_alert(bot, sig, subscribers, now)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.error(f"Сбой в скринере: {e}")
            await asyncio.sleep(CHECK_INTERVAL_SEC)
    except asyncio.CancelledError:
        pass
    finally:
        await scanner.close()