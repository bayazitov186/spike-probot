import asyncio
import html
import logging
import os
import tempfile
import time
import urllib.request
from datetime import datetime, timezone, timedelta

import aiosqlite
import feedparser
from aiogram import Bot
from aiogram.types import FSInputFile, LinkPreviewOptions

from config import state as app_state, DB_PATH, ADMIN_IDS, CHANNEL_ID, CRYPTO_RSS_URL
from database import get_bot_setting, set_bot_setting

logger = logging.getLogger("SpikePRO.Maint")

TZ_MSK = timezone(timedelta(hours=3))


async def build_evening_digest_text() -> str:
    one_day_ago = time.time() - 86400
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT COUNT(*) as total FROM signals_history WHERE created_at >= ?",
            (one_day_ago,)
        ) as cur:
            total_signals = (await cur.fetchone())["total"] or 0

        async with db.execute("""
            SELECT symbol, side, vol_ratio, oi_change, max_profit_1h
            FROM signals_history
            WHERE created_at >= ? AND max_profit_1h > 0
            ORDER BY max_profit_1h DESC LIMIT 3
        """, (one_day_ago,)) as cur_top:
            top_rows = [dict(r) for r in await cur_top.fetchall()]

    if total_signals == 0 or not top_rows:
        return ""

    date_str = datetime.now(TZ_MSK).strftime("%d.%m.%Y")
    lines = [
        f"🌙 <b>Вечерний дайджест Spike PRO ({date_str})</b>\n",
        f"📊 Зафиксировано рыночных импульсов за 24ч: <b>{total_signals}</b>\n",
        "🏆 <b>Самые волатильные движения суток (по данным ПО):</b>"
    ]
    for idx, r in enumerate(top_rows, start=1):
        dot = "🟢" if r["side"] == "LONG" else "🔴"
        lines.append(
            f"{idx}. {dot} <b>#{r['symbol']}</b> ({r['side']}) — амплитуда <code>+{r['max_profit_1h']:.2f}%</code> "
            f"(Vol <code>x{r['vol_ratio']:.1f}</code> | OI <code>{r['oi_change']:+.2f}%</code>)"
        )

    lines.append(
        f"\n🤖 <a href='https://t.me/{app_state.cached_bot_username}'>Настроить персональные фильтры в Spike PRO</a>\n"
        f"<i>Сводка сформирована автоматически на основе биржевой статистики. Не является ИИР.</i>"
    )
    return "\n".join(lines)


async def send_evening_digest_if_due(bot: Bot, force: bool = False) -> bool:
    if not CHANNEL_ID:
        return False

    now_msk = datetime.now(TZ_MSK)
    today_key = now_msk.strftime("%Y-%m-%d")

    if not force:
        if app_state.emergency_pause or now_msk.hour != 21:
            return False
        last_sent_date = await get_bot_setting("last_digest_date", "")
        if last_sent_date == today_key:
            return False

    digest_text = await build_evening_digest_text()
    if not digest_text:
        return False

    try:
        await bot.send_message(
            chat_id=CHANNEL_ID,
            text=digest_text,
            link_preview_options=LinkPreviewOptions(is_disabled=True)
        )
        await set_bot_setting("last_digest_date", today_key)
        logger.info(f"Вечерний дайджест за {today_key} успешно опубликован в канал.")
        return True
    except Exception as e:
        logger.error(f"Ошибка отправки вечернего дайджеста: {e}")
        return False


async def backup_worker(bot: Bot):
    backup_file_path = os.path.join(tempfile.gettempdir(), "backup_snapshot.db")
    while True:
        try:
            await asyncio.sleep(86400)
            async with aiosqlite.connect(DB_PATH, timeout=30) as src_db, aiosqlite.connect(backup_file_path) as dst_db:
                await src_db.backup(dst_db)
            for admin_id in ADMIN_IDS:
                if admin_id <= 0:
                    continue
                try:
                    file = FSInputFile(backup_file_path)
                    date_str = datetime.now().strftime("%Y-%m-%d")
                    await bot.send_document(chat_id=admin_id, document=file, caption=f"📦 Spike PRO Слепок БД ({date_str})")
                except Exception:
                    pass
                finally:
                    await asyncio.sleep(0.1)
            if os.path.exists(backup_file_path):
                os.remove(backup_file_path)
        except asyncio.CancelledError:
            break
        except Exception:
            await asyncio.sleep(3600)


def _safe_parse_feed(url: str):
    req = urllib.request.Request(
        url,
        headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
    )
    with urllib.request.urlopen(req, timeout=10) as response:
        return feedparser.parse(response.read())


async def crypto_news_worker(bot: Bot):
    await asyncio.sleep(15)
    last_news_check = 0.0
    while True:
        try:
            await send_evening_digest_if_due(bot, force=False)

            now_ts = time.time()
            if CHANNEL_ID and not app_state.emergency_pause and (now_ts - last_news_check) >= 1800:
                last_news_check = now_ts
                feed = await asyncio.to_thread(_safe_parse_feed, CRYPTO_RSS_URL)
                if feed and feed.entries:
                    latest_news = feed.entries[0]
                    news_id = latest_news.get("id") or latest_news.get("link")
                    if news_id:
                        async with aiosqlite.connect(DB_PATH, timeout=30) as db:
                            cur = await db.execute(
                                "INSERT OR IGNORE INTO news_cache (news_id, sent_at) VALUES (?, ?)",
                                (news_id, now_ts)
                            )
                            is_new = cur.rowcount > 0
                            if is_new:
                                await db.execute("DELETE FROM news_cache WHERE sent_at < ?", (now_ts - 7 * 86400,))
                            await db.commit()

                        if is_new:
                            raw_title = html.unescape(latest_news.get("title") or "Дайджест рынка")
                            title = html.escape(raw_title)
                            link = latest_news.get("link") or ""
                            news_text = (
                                f"📰 <b>Информационный дайджест</b>\n\n"
                                f"<b>{title}</b>\n\n"
                                f"🔗 <a href='{link}'>Читать источник</a>\n\n"
                                f"🤖 <a href='https://t.me/{app_state.cached_bot_username}'>ПО Spike PRO — мониторинг метрик</a>"
                            )
                            try:
                                await bot.send_message(
                                    chat_id=CHANNEL_ID,
                                    text=news_text,
                                    link_preview_options=LinkPreviewOptions(is_disabled=False)
                                )
                            except Exception as e:
                                logger.warning(f"Ошибка отправки новости в канал: {e}")
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.warning(f"Сбой в crypto_news_worker: {e}")
        await asyncio.sleep(60)