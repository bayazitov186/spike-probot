import asyncio
from aiogram import Bot

from workers.bybit_screener import screener_worker
from workers.tracker import performance_tracker_worker
from workers.solana_sniper import sniper_worker
from workers.maintenance import backup_worker, crypto_news_worker


def start_background_workers(bot: Bot) -> list[asyncio.Task]:
    return [
        asyncio.create_task(screener_worker(bot), name="screener"),
        asyncio.create_task(sniper_worker(bot), name="sniper"),
        asyncio.create_task(backup_worker(bot), name="backup"),
        asyncio.create_task(crypto_news_worker(bot), name="news"),
        asyncio.create_task(performance_tracker_worker(bot), name="tracker"),
    ]