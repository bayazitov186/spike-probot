import asyncio
import html
import json
import logging
import time
from datetime import datetime
from typing import Optional, Set

import aiohttp
import websockets
from aiogram import Bot
from aiogram.types import LinkPreviewOptions

from config import (
    state as app_state, SOLANA_WSS, PROXY_URL, CHANNEL_ID, ADMIN_IDS,
    BASE_TOKENS, RAYDIUM_V4_PROGRAM_ID, RAYDIUM_CPMM_PROGRAM_ID,
    MIN_POOL_LIQUIDITY_USD, SNIPER_GLOBAL_COOLDOWN_SEC,
    CHANNEL_SOLANA_MIN_LIQUIDITY_USD, CHANNEL_SOLANA_INTERVAL_SEC, CHANNEL_SOLANA_DAILY_LIMIT,
    FOMO_BASE_URL, FOMO_REF_CODE, TZ_LOCAL
)
from database import (
    set_bot_setting, is_token_processed, save_token,
    cleanup_old_tokens, get_active_subscribers
)
from keyboards import create_sniper_keyboard

logger = logging.getLogger("SpikePRO.Solana")

signature_resolve_lock = asyncio.Lock()
sniper_dispatch_lock = asyncio.Lock()
sniper_semaphore = asyncio.Semaphore(3)


async def auto_disable_solana_on_limit(bot: Bot):
    if not app_state.solana_enabled:
        return
    app_state.solana_enabled = False
    await set_bot_setting("solana_sniper_enabled", "0")
    logger.warning("Мониторинг Solana автоматически отключен из-за исчерпания лимитов Helius RPC (HTTP 429).")
    for adm in ADMIN_IDS:
        if adm > 0:
            try:
                await bot.send_message(
                    adm,
                    "⚠️ <b>Лимиты Helius RPC исчерпаны (429)!</b>\n\n"
                    "Мониторинг пулов Solana автоматически переведён в режим <b>ВЫКЛ 🔴</b>, чтобы бот не падал в ошибки.\n"
                    "Включить обратно после пополнения лимитов можно в <code>/admin</code>."
                )
            except Exception:
                pass


def is_raydium_pool_created(logs: list) -> bool:
    logs_str = " ".join(logs).lower()
    if "program cpmmoo8l3f4nbtegbckvnunggl7h1zpdthkxqb5qkp1c" in logs_str and "instruction: initialize" in logs_str:
        return True
    if "instruction: initializeinstruction2" in logs_str or "initialize2" in logs_str:
        return True
    return False


async def resolve_signature_to_mint(bot: Bot, signature: str, session: aiohttp.ClientSession) -> str:
    if not SOLANA_WSS or not app_state.solana_enabled:
        return ""
    http_url = SOLANA_WSS.replace("wss://", "https://")
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "getTransaction",
        "params": [signature, {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 0}]
    }
    for _ in range(3):
        if not app_state.solana_enabled:
            return ""
        await asyncio.sleep(2.0)
        try:
            async with session.post(http_url, json=payload, proxy=PROXY_URL, timeout=5) as resp:
                if resp.status == 429:
                    await auto_disable_solana_on_limit(bot)
                    return ""
                if resp.status == 200:
                    data = await resp.json()
                    meta = (data.get("result") or {}).get("meta") or {}
                    balances = meta.get("postTokenBalances") or []
                    for b in balances:
                        mint = (b or {}).get("mint")
                        if mint and mint not in BASE_TOKENS:
                            return mint
        except Exception:
            pass
    return ""


async def fetch_token_enriched_data(mint: str, session: aiohttp.ClientSession) -> Optional[dict]:
    url = f"https://api.dexscreener.com/latest/dex/tokens/{mint}"
    for attempt in range(4):
        await asyncio.sleep(2.5 if attempt > 0 else 1.5)
        try:
            async with session.get(url, timeout=5, proxy=PROXY_URL) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    pairs = data.get("pairs") or []
                    if pairs:
                        pairs.sort(key=lambda p: float((p.get("liquidity") or {}).get("usd") or 0), reverse=True)
                        target_pair = pairs[0]
                        base_t = target_pair.get("baseToken") or {}
                        liq_usd = float((target_pair.get("liquidity") or {}).get("usd") or 0)
                        price_usd = target_pair.get("priceUsd") or "0.0"

                        return {
                            "name": base_t.get("name") or "Unknown Token",
                            "symbol": base_t.get("symbol") or "TOKEN",
                            "liquidity_usd": liq_usd,
                            "price_usd": price_usd,
                            "dex": (target_pair.get("dexId") or "raydium").upper(),
                            "url": target_pair.get("url") or f"https://dexscreener.com/solana/{mint}"
                        }
        except Exception:
            pass
    return None


async def fetch_rugcheck_summary(mint: str, session: aiohttp.ClientSession) -> dict:
    url = f"https://api.rugcheck.xyz/v1/tokens/{mint}/report/summary"
    for attempt in range(2):
        if attempt > 0:
            await asyncio.sleep(2.0)
        try:
            async with session.get(url, timeout=5, proxy=PROXY_URL) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    score = data.get("score")
                    if score is None:
                        score = 0
                    risks = data.get("risks") or []

                    mint_disabled = not any("mint" in str((r or {}).get("name") or "").lower() for r in risks)
                    freeze_disabled = not any("freeze" in str((r or {}).get("name") or "").lower() for r in risks)
                    is_dang = score >= 2000 or any((r or {}).get("level") == "danger" for r in risks)

                    if score < 500:
                        status_text = "🟢 Good (Низкий риск)"
                    elif score < 2000:
                        status_text = "🟡 Warning (Средний риск)"
                    else:
                        status_text = "🔴 DANGER (Высокий риск)"

                    mint_str = "Отключен ✅" if mint_disabled else "Включен ⚠️"
                    freeze_str = "Отключен ✅" if freeze_disabled else "Включен ⚠️"

                    return {
                        "status": status_text,
                        "mint_str": mint_str,
                        "freeze_str": freeze_str,
                        "is_dangerous": is_dang
                    }
        except Exception:
            pass

    return {
        "status": "⚪️ Не проверено",
        "mint_str": "Неизвестно",
        "freeze_str": "Неизвестно",
        "is_dangerous": False
    }


async def process_new_pool_task(bot: Bot, signature: str, http_session: aiohttp.ClientSession):
    if not app_state.solana_enabled:
        return

    async with sniper_semaphore:
        if not app_state.solana_enabled:
            return
        now = time.time()
        if (now - app_state.last_sniper_alert_time) < SNIPER_GLOBAL_COOLDOWN_SEC:
            return

        stale_mints = [m for m, ts in app_state.processed_mints_cache.items() if now - ts > 86400]
        for m in stale_mints:
            del app_state.processed_mints_cache[m]

        async with signature_resolve_lock:
            if not app_state.solana_enabled or (time.time() - app_state.last_sniper_alert_time) < SNIPER_GLOBAL_COOLDOWN_SEC:
                return
            mint_address = await resolve_signature_to_mint(bot, signature, http_session)
            if not mint_address:
                return

            if mint_address in app_state.pending_mints_lock or mint_address in app_state.processed_mints_cache:
                return
            if await is_token_processed(mint_address):
                app_state.processed_mints_cache[mint_address] = now
                return

            app_state.pending_mints_lock.add(mint_address)

        try:
            if not app_state.solana_enabled or (time.time() - app_state.last_sniper_alert_time) < SNIPER_GLOBAL_COOLDOWN_SEC:
                return

            meta = await fetch_token_enriched_data(mint_address, http_session)
            if not meta or meta.get('liquidity_usd', 0) < MIN_POOL_LIQUIDITY_USD:
                return

            rug_info = await fetch_rugcheck_summary(mint_address, http_session)

            if (rug_info.get("is_dangerous", False) or
                "DANGER" in rug_info.get("status", "") or
                "Включен" in rug_info.get("freeze_str", "")):
                app_state.processed_mints_cache[mint_address] = time.time()
                await save_token(mint_address, meta.get('liquidity_usd', 0))
                return

            async with sniper_dispatch_lock:
                if not app_state.solana_enabled or (time.time() - app_state.last_sniper_alert_time) < SNIPER_GLOBAL_COOLDOWN_SEC:
                    return
                app_state.processed_mints_cache[mint_address] = time.time()
                await save_token(mint_address, meta.get('liquidity_usd', 0))
                app_state.last_sniper_alert_time = time.time()

            subscribers = await get_active_subscribers()
            liq_usd = meta['liquidity_usd']
            start_time_str = datetime.now(TZ_LOCAL).strftime("%H:%M:%S (UTC+5)")
            rug_short = "🟢 Good" if "Good" in rug_info['status'] else ("🟡 Warning" if "Warning" in rug_info['status'] else "⚪️ Pending")
            fomo_mobile_line = f"\n\n📱 <a href='{FOMO_BASE_URL}/r/{FOMO_REF_CODE}'>Открыть обозреватель FOMO</a>" if FOMO_REF_CODE else ""

            safe_name = html.escape(str(meta['name']))
            safe_symbol = html.escape(str(meta['symbol']))

            user_text = (
                f"🎯 <b>${safe_symbol}</b> | <b>Liq:</b> <code>${liq_usd:,.0f}</code> | {rug_short}\n\n"
                f"💎 <b>Контракт:</b> {safe_name} (Raydium)\n"
                f"📝 <b>Адрес:</b>\n<code>{mint_address}</code>\n\n"
                f"💲 <b>Стартовая котировка:</b> <code>${meta['price_usd']}</code>\n"
                f"⏰ <b>Время фиксации:</b> <code>{start_time_str}</code>\n\n"
                f"🛡 <b>Технический отчёт RugCheck:</b>\n"
                f"• Статус: {rug_info['status']}\n"
                f"• Mint Authority: {rug_info['mint_str']}\n"
                f"• Freeze Authority: {rug_info['freeze_str']}{fomo_mobile_line}\n"
                f"<i>Автоматический ончейн-мониторинг. Не является ИИР.</i>"
            )
            kb = create_sniper_keyboard(mint_address, meta['url'])

            for sub in subscribers:
                try:
                    await bot.send_message(chat_id=sub['user_id'], text=user_text, reply_markup=kb, link_preview_options=LinkPreviewOptions(is_disabled=True))
                except Exception:
                    pass
                finally:
                    await asyncio.sleep(0.04)

            now_post = time.time()
            current_day = time.strftime("%Y-%m-%d", time.localtime(now_post))
            stored_day = time.strftime("%Y-%m-%d", time.localtime(app_state.channel_solana_day_timestamp))
            if current_day != stored_day:
                app_state.channel_solana_posts_today = 0
                app_state.channel_solana_day_timestamp = now_post

            time_since_last_sol = now_post - app_state.channel_solana_last_post_time

            if (CHANNEL_ID and
                liq_usd >= CHANNEL_SOLANA_MIN_LIQUIDITY_USD and
                time_since_last_sol >= CHANNEL_SOLANA_INTERVAL_SEC and
                app_state.channel_solana_posts_today < CHANNEL_SOLANA_DAILY_LIMIT):

                app_state.channel_solana_last_post_time = now_post
                app_state.channel_solana_posts_today += 1

                chan_text = (
                    f"🎯 <b>Новый пул Raydium</b> (Мониторинг #{app_state.channel_solana_posts_today}/{CHANNEL_SOLANA_DAILY_LIMIT})\n\n"
                    f"💎 <b>${safe_symbol}</b> ({safe_name})\n"
                    f"💧 <b>Ликвидность:</b> <code>${liq_usd:,.0f}</code>\n"
                    f"💲 <b>Старт:</b> <code>${meta['price_usd']}</code>\n"
                    f"⏰ <b>Время фиксации:</b> <code>{start_time_str}</code>\n\n"
                    f"🛡 <b>Отчёт RugCheck:</b> {rug_info['status']}\n\n"
                    f"📝 <b>Адрес контракта:</b>\n<code>{mint_address}</code>\n\n"
                    f"🤖 <a href='https://t.me/{app_state.cached_bot_username}'>ПО Spike PRO — мониторинг метрик</a>\n"
                    f"<i>Информация носит справочный характер. Не ИИР.</i>"
                )
                try:
                    await bot.send_message(chat_id=CHANNEL_ID, text=chan_text, link_preview_options=LinkPreviewOptions(is_disabled=True))
                except Exception as e:
                    logger.error(f"Ошибка публикации пула в канал: {e}")

        finally:
            app_state.pending_mints_lock.discard(mint_address)


async def sniper_worker(bot: Bot):
    last_cleanup = 0
    http_session = aiohttp.ClientSession()
    active_pool_tasks: Set[asyncio.Task] = set()
    try:
        while True:
            try:
                if time.time() - last_cleanup > 3600:
                    await cleanup_old_tokens()
                    last_cleanup = time.time()

                if not SOLANA_WSS or not app_state.solana_enabled:
                    await asyncio.sleep(5)
                    continue

                async with websockets.connect(SOLANA_WSS, ping_interval=15, ping_timeout=15, max_queue=100) as ws:
                    for idx, prog_id in enumerate([RAYDIUM_V4_PROGRAM_ID, RAYDIUM_CPMM_PROGRAM_ID], start=1):
                        msg = {
                            "jsonrpc": "2.0",
                            "id": idx,
                            "method": "logsSubscribe",
                            "params": [{"mentions": [prog_id]}, {"commitment": "confirmed"}]
                        }
                        await ws.send(json.dumps(msg))

                    while app_state.solana_enabled:
                        try:
                            message = await asyncio.wait_for(ws.recv(), timeout=5.0)
                        except asyncio.TimeoutError:
                            continue

                        try:
                            data = json.loads(message)
                        except Exception:
                            continue

                        if 'error' in data:
                            err_str = str(data['error'])
                            logger.error(f"Ошибка Solana WSS: {err_str}")
                            if "429" in err_str or "rate" in err_str.lower() or "limit" in err_str.lower():
                                await auto_disable_solana_on_limit(bot)
                                break
                            continue

                        if data.get('method') == 'logsNotification':
                            val = (data.get('params') or {}).get('result', {}).get('value') or {}
                            if val.get('err') is not None:
                                continue

                            logs = val.get('logs') or []
                            signature = val.get('signature') or ''

                            if not logs or not signature or app_state.emergency_pause or not app_state.solana_enabled:
                                continue

                            if signature in app_state.processed_signatures_cache:
                                continue
                            app_state.processed_signatures_cache[signature] = time.time()
                            if len(app_state.processed_signatures_cache) > 2000:
                                oldest_sig = next(iter(app_state.processed_signatures_cache))
                                del app_state.processed_signatures_cache[oldest_sig]

                            if is_raydium_pool_created(logs):
                                if (time.time() - app_state.last_sniper_alert_time) >= SNIPER_GLOBAL_COOLDOWN_SEC:
                                    task = asyncio.create_task(process_new_pool_task(bot, signature, http_session))
                                    active_pool_tasks.add(task)
                                    task.add_done_callback(active_pool_tasks.discard)
            except websockets.exceptions.ConnectionClosed:
                await asyncio.sleep(5)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                err_msg = str(e)
                if "429" in err_msg:
                    await auto_disable_solana_on_limit(bot)
                else:
                    logger.error(f"Сбой в sniper_worker: {e}")
                await asyncio.sleep(5)
    except asyncio.CancelledError:
        pass
    finally:
        for t in list(active_pool_tasks):
            t.cancel()
        if active_pool_tasks:
            await asyncio.gather(*active_pool_tasks, return_exceptions=True)
        await http_session.close()